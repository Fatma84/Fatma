(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /home/fatma/Desktop/Fatma portfolio0/src/main.ts */"zUnb");


/***/ }),

/***/ "1qzX":
/*!***************************************************!*\
  !*** ./src/app/core/sidebar/sidebar.component.ts ***!
  \***************************************************/
/*! exports provided: SidebarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidebarComponent", function() { return SidebarComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");

class SidebarComponent {
    constructor() { }
    ngOnInit() {
    }
}
SidebarComponent.ɵfac = function SidebarComponent_Factory(t) { return new (t || SidebarComponent)(); };
SidebarComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: SidebarComponent, selectors: [["app-sidebar"]], decls: 2, vars: 0, template: function SidebarComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "sidebar works!");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzaWRlYmFyLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ "2g2N":
/*!*******************************************!*\
  !*** ./src/app/services/toast.service.ts ***!
  \*******************************************/
/*! exports provided: ToastService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastService", function() { return ToastService; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");



class ToastService {
    constructor() {
        this.toasts = new rxjs__WEBPACK_IMPORTED_MODULE_0__["BehaviorSubject"]([]);
    }
    addToast(toast) {
        this.toasts.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["take"])(1)).subscribe((toasts) => {
            let _toasts = toasts;
            _toasts.push(toast);
            this.toasts.next(_toasts);
            setTimeout(() => {
                this.removeFirstToast();
            }, 5000);
        });
    }
    removeFirstToast() {
        this.toasts.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["take"])(1)).subscribe((toasts) => {
            let _toasts = toasts;
            _toasts.shift();
            this.toasts.next(_toasts);
        });
    }
}
ToastService.ɵfac = function ToastService_Factory(t) { return new (t || ToastService)(); };
ToastService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: ToastService, factory: ToastService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "2hTU":
/*!***********************************************!*\
  !*** ./src/app/core/toast/toast.component.ts ***!
  \***********************************************/
/*! exports provided: ToastComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastComponent", function() { return ToastComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/toast.service */ "2g2N");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");



function ToastComponent_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "button", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const toast_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", "bg-" + toast_r1.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](toast_r1.message);
} }
class ToastComponent {
    constructor(toastService) {
        this.toastService = toastService;
    }
    ngOnInit() { }
}
ToastComponent.ɵfac = function ToastComponent_Factory(t) { return new (t || ToastComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_1__["ToastService"])); };
ToastComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ToastComponent, selectors: [["app-toast"]], decls: 3, vars: 3, consts: [[1, "toast-container"], [4, "ngFor", "ngForOf"], [1, "animate__animated", "animate__fadeInUp"], ["role", "alert", "aria-live", "assertive", "aria-atomic", "true", 1, "toast", "d-flex", "align-items-center", "text-white", "border-0", 3, "ngClass"], [1, "toast-body"], ["type", "button", "data-bs-dismiss", "toast", "aria-label", "Close", 1, "btn-close", "btn-close-white", "ms-auto", "me-2"]], template: function ToastComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ToastComponent_ng_container_1_Template, 6, 2, "ng-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 1, ctx.toastService.toasts));
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["AsyncPipe"]], styles: [".toast-container[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: 10px;\n  right: 10px;\n  z-index: 2000;\n}\n\n.toast[_ngcontent-%COMP%] {\n  max-width: calc(100vw - 20px);\n  opacity: 1 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3RvYXN0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0UsZUFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtBQUFGOztBQUVBO0VBQ0UsNkJBQUE7RUFDQSxxQkFBQTtBQUNGIiwiZmlsZSI6InRvYXN0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4udG9hc3QtY29udGFpbmVyIHtcbiAgcG9zaXRpb246IGZpeGVkO1xuICBib3R0b206IDEwcHg7XG4gIHJpZ2h0OiAxMHB4O1xuICB6LWluZGV4OiAyMDAwO1xufVxuLnRvYXN0IHtcbiAgbWF4LXdpZHRoOiBjYWxjKDEwMHZ3IC0gMjBweCk7XG4gIG9wYWNpdHk6IDEhaW1wb3J0YW50O1xufVxuIl19 */"] });


/***/ }),

/***/ "6Qg2":
/*!*******************************************!*\
  !*** ./src/app/services/users.service.ts ***!
  \*******************************************/
/*! exports provided: UsersService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersService", function() { return UsersService; });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");



class UsersService {
    constructor(firestore) {
        this.firestore = firestore;
        this.usersCollection = this.firestore.collection('users');
    }
    getUsers() {
        return this.usersCollection.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_0__["map"])((res) => {
            return res.map((e) => {
                return Object.assign(Object.assign({}, e.payload.doc.data()), { uid: e.payload.doc.id });
            });
        }));
    }
    addUser(user) {
        return this.usersCollection.add(user);
    }
    deleteUser(UID) {
        return this.usersCollection.doc(UID).delete();
    }
}
UsersService.ɵfac = function UsersService_Factory(t) { return new (t || UsersService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"])); };
UsersService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: UsersService, factory: UsersService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "7fBr":
/*!**********************************************************!*\
  !*** ./src/app/core/modals/join-team/join-team.modal.ts ***!
  \**********************************************************/
/*! exports provided: JoinTeamComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JoinTeamComponent", function() { return JoinTeamComponent; });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../toast/Toast.model */ "Lby2");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var src_app_services_team_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/team.service */ "GDbA");
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/toast.service */ "2g2N");
/* harmony import */ var _shared_components_user_account_user_account_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/components/user-account/user-account.component */ "bT90");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "ofXK");









function JoinTeamComponent_span_47_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Say It");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function JoinTeamComponent_span_48_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Flying...");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
class JoinTeamComponent {
    constructor(fb, authService, teamService, toastService) {
        this.fb = fb;
        this.authService = authService;
        this.teamService = teamService;
        this.toastService = toastService;
        this.user = null;
        this.teamForm = this.fb.group({
            position: [''],
            description: [
                '',
                [
                    _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].minLength(3),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].maxLength(1000),
                ],
            ],
            facebook: [''],
            instagram: [''],
            twitter: [''],
            linkedin: [''],
        });
        this.isSending = false;
    }
    get position() {
        return this.teamForm.get('position');
    }
    get description() {
        return this.teamForm.get('description');
    }
    get facebook() {
        return this.teamForm.get('facebook');
    }
    get instagram() {
        return this.teamForm.get('instagram');
    }
    get twitter() {
        return this.teamForm.get('twitter');
    }
    get linkedin() {
        return this.teamForm.get('linkedin');
    }
    ngOnInit() {
        this.userSubs();
    }
    userSubs() {
        this.authService.user$.subscribe((user) => (this.user = user));
    }
    onSendForm() {
        if (this.teamForm.invalid)
            return;
        this.isSending = true;
        this.teamForm.disable();
        if (!this.user)
            return;
        let teamForm = {
            uid: this.user.uid,
            position: this.position.value,
            description: this.description.value,
            social: {
                facebook: this.facebook.value,
                instagram: this.instagram.value,
                twitter: this.twitter.value,
                linkedin: this.linkedin.value,
            },
            approved: false,
        };
        this.teamService.addTeam(teamForm).then((res) => {
            let toast = new _toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__["Toast"]('message sent successfully', 'Thank You, I just recieved your team', 2);
            this.toastService.addToast(toast);
            this.isSending = false;
            this.resetForm();
            this.teamForm.enable();
        }, (err) => {
            let toast = new _toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__["Toast"]('Error', 'There is an error in sending your team', 2);
            this.toastService.addToast(toast);
            this.isSending = false;
            this.teamForm.enable();
        });
    }
    resetForm() {
        this.teamForm.reset({
            position: '',
            description: '',
        });
    }
}
JoinTeamComponent.ɵfac = function JoinTeamComponent_Factory(t) { return new (t || JoinTeamComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_team_service__WEBPACK_IMPORTED_MODULE_4__["TeamService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"])); };
JoinTeamComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: JoinTeamComponent, selectors: [["modal-join-team"]], decls: 50, vars: 14, consts: [["id", "teamModal", "tabindex", "-1", "aria-labelledby", "teamModalLabel", "aria-hidden", "true", 1, "modal", "fade"], [1, "modal-dialog", "modal-fullscreen"], [1, "modal-content"], [1, "modal-body"], [1, "d-flex", "justify-content-between", "align-items-center", "border-0"], ["src", "assets/imgs/logo/omar-logo.png", "alt", "omar logo", "width", "80px"], [1, "text-center"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn", "icon-cancel"], ["id", "teamForm", 1, "row", "say-hello-form", 3, "formGroup", "ngSubmit"], [1, "col-12"], [1, "form-floating", "mb-4"], ["id", "position", "type", "text", "formControlName", "position", "placeholder", "Sr. System Developers, Domain7", 1, "form-control"], ["for", "position"], ["id", "description", "formControlName", "description", "placeholder", "tell me <3", 1, "form-control", "form-control-lg", 2, "min-height", "190px"], ["for", "description", 1, "form-label"], [1, "invalid-feedback"], ["id", "facebook", "type", "text", "formControlName", "facebook", "placeholder", "Sr. System Developers, Domain7", 1, "form-control"], ["for", "facebook"], ["id", "instagram", "type", "text", "formControlName", "instagram", "placeholder", "Sr. System Developers, Domain7", 1, "form-control"], ["for", "instagram"], ["id", "twitter", "type", "text", "formControlName", "twitter", "placeholder", "Sr. System Developers, Domain7", 1, "form-control"], ["for", "twitter"], ["id", "linkedin", "type", "text", "formControlName", "linkedin", "placeholder", "Sr. System Developers, Domain7", 1, "form-control"], ["for", "linkedin"], [1, "modal-footer", "border-0", "justify-content-center"], ["type", "submit", "form", "teamForm", 1, "btn", "btn-secondary", "rounded-pill", "btn-lg", "px-5", "d-flex", "align-items-center", 3, "disabled"], [4, "ngIf"], [1, "reset-icon", "ms-2"]], template: function JoinTeamComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "img", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "h2", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](8, "Join the team!");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](9, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](10, "form", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngSubmit", function JoinTeamComponent_Template_form_ngSubmit_10_listener() { return ctx.onSendForm(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](12, "app-user-account");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](15, "input", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](17, "your position (not required) ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](20, "textarea", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](21, "label", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](22, " Descripe your self <3 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](23, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](24, "hey! you have to say it");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](25, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](26, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](27, "input", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](28, "label", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](29, "facebook (not required) ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](30, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](31, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](32, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](33, "label", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](34, "instagram (not required) ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](35, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](36, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](37, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](38, "label", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](39, "twitter (not required) ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](40, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](41, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](42, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](43, "label", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](44, "linkedin (not required) ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](45, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](46, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](47, JoinTeamComponent_span_47_Template, 2, 0, "span", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](48, JoinTeamComponent_span_48_Template, 2, 0, "span", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](49, "i", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx.teamForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("is-invalid", ctx.position.invalid && ctx.position.touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("is-invalid", ctx.description.invalid && ctx.description.touched)("is-valid", ctx.description.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx.teamForm.invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.isSending);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.isSending);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("icon-send", !ctx.isSending)("icon-sending", ctx.isSending);
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_0__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormGroupDirective"], _shared_components_user_account_user_account_component__WEBPACK_IMPORTED_MODULE_6__["UserAccountComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormControlName"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["NgIf"]], styles: [".say-hello-form[_ngcontent-%COMP%] {\n  max-width: 500px;\n  margin: auto;\n  padding: 30px 15px 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2pvaW4tdGVhbS5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7QUFDRiIsImZpbGUiOiJqb2luLXRlYW0ubW9kYWwuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zYXktaGVsbG8tZm9ybSB7XG4gIG1heC13aWR0aDogNTAwcHg7XG4gIG1hcmdpbjogYXV0bztcbiAgcGFkZGluZzogMzBweCAxNXB4IDE1cHg7XG59XG4iXX0= */"] });


/***/ }),

/***/ "AytR":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    firebase: {
        apiKey: 'AIzaSyBAZk8J6CLOy0WPBHly3lwqhTf6xLGPug4',
        authDomain: 'omar-elsayed.firebaseapp.com',
        projectId: 'omar-elsayed',
        storageBucket: 'omar-elsayed.appspot.com',
        messagingSenderId: '383675252591',
        appId: '1:383675252591:web:b98029c337e6b5363df29a',
        measurementId: 'G-4VQYVFEPW7',
    },
    clientId: '383675252591-c3m8m35f49o1ns52p0333apm1fagophf.apps.googleusercontent.com',
    adminID: '7oOSpTnoV2TsUN7w6cqv0a1bvSQ2',
    addClient: 'ca-pub-8195455164873753',
    adSlot: '9756209554',
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "BZQQ":
/*!*************************************!*\
  !*** ./src/app/auth/admin.guard.ts ***!
  \*************************************/
/*! exports provided: AdminGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminGuard", function() { return AdminGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ "AytR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth.service */ "qXBG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");





class AdminGuard {
    constructor(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    canActivate(route, state) {
        return this.handleAuthGuard(route, state);
    }
    canActivateChild(childRoute, state) {
        return this.handleAuthGuard(childRoute, state);
    }
    canLoad(route, segments) {
        return this.handleAuthGuard();
    }
    handleAuthGuard(route, state) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const user = this.authService.user$.value;
            const isAuth = !!user;
            if (!isAuth || (user === null || user === void 0 ? void 0 : user.uid) !== src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].adminID) {
                this.router.navigateByUrl('/');
                return false;
            }
            return true;
        });
    }
}
AdminGuard.ɵfac = function AdminGuard_Factory(t) { return new (t || AdminGuard)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"])); };
AdminGuard.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: AdminGuard, factory: AdminGuard.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "CoJz":
/*!**********************************************!*\
  !*** ./src/app/services/projects.service.ts ***!
  \**********************************************/
/*! exports provided: ProjectsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectsService", function() { return ProjectsService; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _data_frameworks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../data/frameworks */ "YI7L");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");





class ProjectsService {
    constructor(firestore) {
        this.firestore = firestore;
        this.projects = new rxjs__WEBPACK_IMPORTED_MODULE_0__["BehaviorSubject"]([]);
        this.frameworks = _data_frameworks__WEBPACK_IMPORTED_MODULE_2__["FRAMEWORKS"];
        this.projectCollection = this.firestore.collection('projects', (ref) => ref.orderBy('priority'));
    }
    getProjects() {
        return this.projectCollection.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((res) => {
            return res.map((e) => {
                return Object.assign(Object.assign({}, e.payload.doc.data()), { pid: e.payload.doc.id });
            });
        }));
    }
    addProject(project) {
        return this.projectCollection.add(project);
    }
    deleteProject(PID) {
        return this.projectCollection.doc(PID).delete();
    }
}
ProjectsService.ɵfac = function ProjectsService_Factory(t) { return new (t || ProjectsService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__["AngularFirestore"])); };
ProjectsService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: ProjectsService, factory: ProjectsService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "EvY5":
/*!**********************************************************!*\
  !*** ./src/app/core/modals/say-hello/say-hello.modal.ts ***!
  \**********************************************************/
/*! exports provided: SayHelloModal */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SayHelloModal", function() { return SayHelloModal; });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/toast/Toast.model */ "Lby2");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var src_app_services_forms_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/forms.service */ "G9Ti");
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/toast.service */ "2g2N");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "ofXK");








function SayHelloModal_span_45_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Tell me");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function SayHelloModal_span_46_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Flying...");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
class SayHelloModal {
    constructor(fb, authService, formsService, toastService) {
        this.fb = fb;
        this.authService = authService;
        this.formsService = formsService;
        this.toastService = toastService;
        this.user = null;
        this.sayHelloForm = this.fb.group({
            name: [
                '',
                [_angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].maxLength(50)],
            ],
            email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].email]],
            phone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].minLength(11)]],
            message: [
                '',
                [
                    _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].minLength(3),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].maxLength(1000),
                ],
            ],
        });
        this.isSending = false;
    }
    get name() {
        return this.sayHelloForm.get('name');
    }
    get email() {
        return this.sayHelloForm.get('email');
    }
    get phone() {
        return this.sayHelloForm.get('phone');
    }
    get message() {
        return this.sayHelloForm.get('message');
    }
    ngOnInit() {
        this.userSubs();
    }
    userSubs() {
        this.authService.user$.subscribe((user) => {
            this.user = user;
            if (user) {
                this.sayHelloForm.patchValue({
                    name: user.displayName,
                    email: user.email,
                });
            }
            else
                this.sayHelloForm.reset({});
        });
    }
    onSendForm() {
        if (this.sayHelloForm.invalid)
            return;
        this.isSending = true;
        this.sayHelloForm.disable();
        let sayHelloForm = {
            name: this.name.value,
            email: this.email.value,
            phone: this.phone.value,
            message: this.message.value,
        };
        if (this.user) {
            sayHelloForm.uid = this.user.uid;
            sayHelloForm.name = this.user.displayName;
            sayHelloForm.email = this.user.email;
        }
        this.formsService.sendSayHelloForm(sayHelloForm).then((res) => {
            let toast = new src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__["Toast"]('message sent successfully', 'Thank You, I just recieved your message', 2);
            this.toastService.addToast(toast);
            this.isSending = false;
            this.resetForm();
            this.sayHelloForm.enable();
        }, (err) => {
            let toast = new src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__["Toast"]('Error', 'There is an error in sending your message', 2);
            this.toastService.addToast(toast);
            this.isSending = false;
            this.sayHelloForm.enable();
        });
    }
    resetForm() {
        if (!this.user)
            this.sayHelloForm.reset();
        else
            this.sayHelloForm.reset({
                name: this.name.value,
                email: this.email.value,
            });
    }
}
SayHelloModal.ɵfac = function SayHelloModal_Factory(t) { return new (t || SayHelloModal)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_forms_service__WEBPACK_IMPORTED_MODULE_4__["FormsService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"])); };
SayHelloModal.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: SayHelloModal, selectors: [["modal-say-hello"]], decls: 48, vars: 30, consts: [["id", "sayHelloModal", "tabindex", "-1", "aria-labelledby", "sayHelloModalLabel", "aria-hidden", "true", 1, "modal", "fade"], [1, "modal-dialog", "modal-fullscreen"], [1, "modal-content"], [1, "modal-body"], [1, "d-flex", "justify-content-between", "border-0"], ["src", "assets/imgs/logo/omar-logo.png", "alt", "omar logo", "width", "80px"], [1, "text-center"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn", "icon-cancel"], ["id", "sayHelloForm", 1, "row", "say-hello-form", 3, "formGroup", "ngSubmit"], [1, "col-12"], [1, "form-floating", "mb-4"], ["id", "name", "type", "text", "formControlName", "name", "placeholder", "Name", 1, "form-control", 3, "readOnly"], ["for", "name"], [1, "invalid-feedback"], ["id", "email", "type", "email", "formControlName", "email", "placeholder", "name@example.com", 1, "form-control", 3, "readOnly"], ["for", "email"], ["id", "phone", "type", "tel", "formControlName", "phone", "placeholder", "+02 1557032911", "placeholder", "Mobile number", 1, "form-control"], ["for", "phone"], ["id", "message", "formControlName", "message", "placeholder", "Message", 1, "form-control", "form-control-lg", 2, "min-height", "150px"], ["for", "message", 1, "form-label"], [1, "modal-footer", "border-0", "justify-content-center"], ["type", "submit", "form", "sayHelloForm", 1, "btn", "btn-secondary", "rounded-pill", "btn-lg", "px-5", "d-flex", "align-items-center", 3, "disabled"], [4, "ngIf"], [1, "reset-icon", "ms-2"]], template: function SayHelloModal_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "img", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "h2", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](8, " Thanks for taking the time to reach out. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](9, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10, " How can I help you today? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](11, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "form", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngSubmit", function SayHelloModal_Template_form_ngSubmit_12_listener() { return ctx.onSendForm(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](15, "input", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](16, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](17, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](18, "Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](20, "What's your name?");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](21, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](23, "input", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](24, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](25, "label", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](26, "Email address");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](27, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](28, "Tell me your email so that I can reply to you");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](29, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](30, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](31, "input", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](32, "label", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](33, "Mobile Number");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](34, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](35, "give me a real number plz.");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](36, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](37, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](38, "textarea", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](39, "label", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](40, "Write your message");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](41, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](42, "I will try my best to help you with whatever you want");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](43, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](44, "button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](45, SayHelloModal_span_45_Template, 2, 0, "span", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](46, SayHelloModal_span_46_Template, 2, 0, "span", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](47, "i", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx.sayHelloForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("is-invalid", ctx.name.invalid && ctx.name.touched)("is-valid", ctx.name.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("readOnly", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](16, 26, ctx.authService.user$));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("is-invalid", ctx.email.invalid && ctx.email.touched)("is-valid", ctx.email.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("readOnly", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](24, 28, ctx.authService.user$));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("is-invalid", ctx.phone.invalid && ctx.phone.touched)("is-valid", ctx.phone.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("is-invalid", ctx.message.invalid && ctx.message.touched)("is-valid", ctx.message.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx.sayHelloForm.invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.isSending);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.isSending);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("icon-send", !ctx.isSending)("icon-sending", ctx.isSending);
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_0__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormGroupDirective"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormControlName"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgIf"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["AsyncPipe"]], styles: [".say-hello-form[_ngcontent-%COMP%] {\n  max-width: 500px;\n  margin: auto;\n  padding: 30px 15px 15px;\n}\n\n.form-floating[_ngcontent-%COMP%]    > .form-control[_ngcontent-%COMP%]:not(:-moz-placeholder-shown) {\n  color: #ff8da1;\n  font-weight: bold;\n}\n\n.form-floating[_ngcontent-%COMP%]    > .form-control[_ngcontent-%COMP%]:not(:-ms-input-placeholder) {\n  color: #ff8da1;\n  font-weight: bold;\n}\n\n.form-floating[_ngcontent-%COMP%]    > .form-control[_ngcontent-%COMP%]:focus, .form-floating[_ngcontent-%COMP%]    > .form-control[_ngcontent-%COMP%]:not(:placeholder-shown) {\n  color: #ff8da1;\n  font-weight: bold;\n}\n\n.btn-secondary[_ngcontent-%COMP%]:disabled, .btn-secondary.disabled[_ngcontent-%COMP%] {\n  background: #ff8da1;\n  border-color: #ff8da1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NheS1oZWxsby5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7QUFDRjs7QUFFQTtFQUVFLGNBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUpBO0VBRUUsY0FBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBSkE7O0VBRUUsY0FBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDSSxtQkFBQTtFQUNBLHFCQUFBO0FBQ0oiLCJmaWxlIjoic2F5LWhlbGxvLm1vZGFsLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2F5LWhlbGxvLWZvcm0ge1xuICBtYXgtd2lkdGg6IDUwMHB4O1xuICBtYXJnaW46IGF1dG87XG4gIHBhZGRpbmc6IDMwcHggMTVweCAxNXB4O1xufVxuXG4uZm9ybS1mbG9hdGluZyA+IC5mb3JtLWNvbnRyb2w6Zm9jdXMsIFxuLmZvcm0tZmxvYXRpbmcgPiAuZm9ybS1jb250cm9sOm5vdCg6cGxhY2Vob2xkZXItc2hvd24pIHtcbiAgY29sb3I6ICNmZjhkYTE7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4uYnRuLXNlY29uZGFyeTpkaXNhYmxlZCwgLmJ0bi1zZWNvbmRhcnkuZGlzYWJsZWQge1xuICAgIGJhY2tncm91bmQ6ICNmZjhkYTE7XG4gICAgYm9yZGVyLWNvbG9yOiAjZmY4ZGExO1xufSJdfQ== */"] });


/***/ }),

/***/ "F5nt":
/*!********************************!*\
  !*** ./src/app/app.service.ts ***!
  \********************************/
/*! exports provided: AppService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppService", function() { return AppService; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");



class AppService {
    constructor() {
        this.isDarkMode$ = new rxjs__WEBPACK_IMPORTED_MODULE_0__["BehaviorSubject"](false);
        this.getMode();
    }
    getMode() {
        const savedMode = localStorage.getItem('mode');
        let defaultMode = savedMode == 'dark-mode' ? 'dark-mode' : 'light-mode';
        this.isDarkMode$.next(defaultMode == 'dark-mode');
        this.setMode(defaultMode);
    }
    switchMode() {
        this.isDarkMode$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["take"])(1)).subscribe((isDarkMode) => {
            this.isDarkMode$.next(!isDarkMode);
            const mode = isDarkMode ? 'light-mode' : 'dark-mode';
            this.setMode(mode);
        });
    }
    setMode(mode) {
        const bodyClass = document.body.classList;
        localStorage.setItem('mode', mode);
        bodyClass.remove('dark-mode', 'light-mode');
        bodyClass.add(mode);
    }
    initWOW() {
        var wow = new WOW({
            boxClass: 'wow',
            animateClass: 'animated',
            offset: 0,
            mobile: true,
            live: true,
            callback: function (box) {
                // the callback is fired every time an animation is started
                // the argument that is passed in is the DOM node being animated
            },
            scrollContainer: null,
            resetAnimation: true,
        });
        wow.init();
    }
}
AppService.ɵfac = function AppService_Factory(t) { return new (t || AppService)(); };
AppService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: AppService, factory: AppService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "FxTl":
/*!*************************************************!*\
  !*** ./src/app/core/footer/footer.component.ts ***!
  \*************************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");

class FooterComponent {
    constructor() {
        this.socialMedia = [
            {
                title: 'facebook',
                icon: 'facebook',
                url: 'https://www.facebook.com/profile.php?id=100053868099609',
                target: '_blank',
            },
            {
                title: 'twitter',
                icon: 'twitter',
                url: 'https://twitter.com/OmarEls95211463',
                target: '_blank',
            },
            {
                title: 'linkedin',
                icon: 'linkedin',
                url: 'https://www.linkedin.com/in/challengeromar/',
                target: '_blank',
            },
            {
                title: 'instagram',
                icon: 'instagram',
                url: 'https://www.instagram.com/foxfoxfoc/',
                target: '_blank',
            },
            {
                title: 'whatsapp',
                icon: 'whatsapp',
                url: 'https://wa.me/201557032911',
                target: '_blank',
            },
            {
                title: 'mail',
                icon: 'mail',
                url: 'mailto:challengeromar97@gmail.com',
                target: '_self',
            },
            {
                title: 'phone',
                icon: 'phone',
                url: 'tel:201557032911',
                target: '_self',
            },
        ];
    }
    ngOnInit() { }
}
FooterComponent.ɵfac = function FooterComponent_Factory(t) { return new (t || FooterComponent)(); };
FooterComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FooterComponent, selectors: [["app-footer"]], decls: 5, vars: 0, consts: [[1, "footer"], [1, "container"], [1, "info"], [1, "mb-0", "py-2"]], template: function FooterComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "footer", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "p", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "Copyright \u00A9 2021 Fatma Ahmed. All Rights Reserved");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".footer[_ngcontent-%COMP%] {\n  text-align: center;\n  background: #12181b;\n  color: #fff;\n}\n.footer[_ngcontent-%COMP%]   .start-project[_ngcontent-%COMP%] {\n  position: relative;\n  top: -50px;\n  background-color: #141c3a;\n  box-shadow: 0 5px 5px 0 rgba(0, 0, 0, 0.2), 0 0 0 1px #141c3a;\n  border-radius: 12px;\n  max-width: 95%;\n  margin: auto;\n  padding: 3.5rem 1.25rem;\n  display: flex;\n  justify-content: space-evenly;\n  align-items: center;\n}\n.footer[_ngcontent-%COMP%]   .start-project[_ngcontent-%COMP%]   .start-title[_ngcontent-%COMP%], .footer[_ngcontent-%COMP%]   .start-project[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%] {\n  color: #fff;\n  min-width: -webkit-max-content;\n  min-width: -moz-max-content;\n  min-width: max-content;\n}\n.footer[_ngcontent-%COMP%]   .start-project[_ngcontent-%COMP%]   .start-text[_ngcontent-%COMP%] {\n  max-width: 370px;\n}\n.footer[_ngcontent-%COMP%]   .social-icons[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  list-style-type: none;\n  justify-content: center;\n}\n.footer[_ngcontent-%COMP%]   .social-icons[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  -webkit-margin-end: 10px;\n          margin-inline-end: 10px;\n}\n.footer[_ngcontent-%COMP%]   .social-icons[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  color: #fff;\n}\n.footer[_ngcontent-%COMP%]   .info[_ngcontent-%COMP%]   .info-text[_ngcontent-%COMP%] {\n  color: #fff;\n  font-size: 1.4rem;\n  max-width: 300px;\n  margin: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL2Zvb3Rlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FBQ0Y7QUFDRTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLHlCQUFBO0VBQ0EsNkRBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxhQUFBO0VBQ0EsNkJBQUE7RUFDQSxtQkFBQTtBQUNKO0FBQUk7O0VBRUUsV0FBQTtFQUNBLDhCQUFBO0VBQUEsMkJBQUE7RUFBQSxzQkFBQTtBQUVOO0FBQUk7RUFDRSxnQkFBQTtBQUVOO0FBQ0U7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLHVCQUFBO0FBQ0o7QUFBSTtFQUNFLHdCQUFBO1VBQUEsdUJBQUE7QUFFTjtBQUFJO0VBQ0UsV0FBQTtBQUVOO0FBRUk7RUFDRSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUFBTiIsImZpbGUiOiJmb290ZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZm9vdGVyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kOiAjMTIxODFiO1xuICBjb2xvcjogI2ZmZjtcblxuICAuc3RhcnQtcHJvamVjdCB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHRvcDogLTUwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzE0MWMzYTtcbiAgICBib3gtc2hhZG93OiAwIDVweCA1cHggMCByZ2JhKDAsIDAsIDAsIDAuMiksIDAgMCAwIDFweCAjMTQxYzNhO1xuICAgIGJvcmRlci1yYWRpdXM6IDEycHg7XG4gICAgbWF4LXdpZHRoOiA5NSU7XG4gICAgbWFyZ2luOiBhdXRvO1xuICAgIHBhZGRpbmc6IDMuNXJlbSAxLjI1cmVtO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1ldmVubHk7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAuc3RhcnQtdGl0bGUsXG4gICAgLmJ0biB7XG4gICAgICBjb2xvcjogI2ZmZjtcbiAgICAgIG1pbi13aWR0aDogbWF4LWNvbnRlbnQ7XG4gICAgfVxuICAgIC5zdGFydC10ZXh0IHtcbiAgICAgIG1heC13aWR0aDogMzcwcHg7XG4gICAgfVxuICB9XG4gIC5zb2NpYWwtaWNvbnMge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgbGkge1xuICAgICAgbWFyZ2luLWlubGluZS1lbmQ6IDEwcHg7XG4gICAgfVxuICAgIGkge1xuICAgICAgY29sb3I6ICNmZmY7XG4gICAgfVxuICB9XG4gIC5pbmZvIHtcbiAgICAuaW5mby10ZXh0IHtcbiAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgZm9udC1zaXplOiAxLjRyZW07XG4gICAgICBtYXgtd2lkdGg6IDMwMHB4O1xuICAgICAgbWFyZ2luOiBhdXRvO1xuICAgIH1cbiAgfVxufVxuIl19 */"] });


/***/ }),

/***/ "G9Ti":
/*!*******************************************!*\
  !*** ./src/app/services/forms.service.ts ***!
  \*******************************************/
/*! exports provided: FormsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FormsService", function() { return FormsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");


class FormsService {
    constructor(firestore) {
        this.firestore = firestore;
    }
    sendSayHelloForm(sayHelloForm) {
        return this.firestore.collection('sayHello').add(sayHelloForm);
    }
    sendConversationForm(conversationForm) {
        return this.firestore.collection('conversation').add(conversationForm);
    }
}
FormsService.ɵfac = function FormsService_Factory(t) { return new (t || FormsService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_1__["AngularFirestore"])); };
FormsService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: FormsService, factory: FormsService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "GDbA":
/*!******************************************!*\
  !*** ./src/app/services/team.service.ts ***!
  \******************************************/
/*! exports provided: TeamService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamService", function() { return TeamService; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");
/* harmony import */ var _users_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./users.service */ "6Qg2");





class TeamService {
    constructor(firestore, usersService) {
        this.firestore = firestore;
        this.usersService = usersService;
        this.team = new rxjs__WEBPACK_IMPORTED_MODULE_0__["BehaviorSubject"]([]);
        this.teamCollection = this.firestore.collection('team');
        this.combineUsersWithTeam();
    }
    combineUsersWithTeam() {
        let users = this.usersService.getUsers();
        let team = this.getTeam();
        let res = Object(rxjs__WEBPACK_IMPORTED_MODULE_0__["combineLatest"])([users, team]);
        res.subscribe((res) => {
            let users = res[0];
            let team = [];
            res[1].forEach((_team) => {
                let user = users.find((u) => u.uid === _team.uid);
                if (!user)
                    return;
                team.push(Object.assign(Object.assign({}, _team), { user }));
            });
            this.team.next(team);
        });
    }
    getTeam() {
        return this.teamCollection.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((res) => {
            return res.map((e) => {
                return Object.assign(Object.assign({}, e.payload.doc.data()), { tid: e.payload.doc.id });
            });
        }));
    }
    togglePerson(pid, approved) {
        const personRef = this.firestore.doc(`team/${pid}`);
        personRef.update({ approved });
    }
    addTeam(team) {
        return this.teamCollection.add(team);
    }
    deletePerson(pid) {
        return this.teamCollection.doc(pid).delete();
    }
}
TeamService.ɵfac = function TeamService_Factory(t) { return new (t || TeamService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_3__["AngularFirestore"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_users_service__WEBPACK_IMPORTED_MODULE_4__["UsersService"])); };
TeamService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: TeamService, factory: TeamService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "ImyP":
/*!****************************************************************!*\
  !*** ./src/app/shared/components/project/project.component.ts ***!
  \****************************************************************/
/*! exports provided: ProjectComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectComponent", function() { return ProjectComponent; });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ "AytR");
/* harmony import */ var src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/toast/Toast.model */ "Lby2");
/* harmony import */ var src_app_data_frameworks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/data/frameworks */ "YI7L");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_services_projects_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/projects.service */ "CoJz");
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/toast.service */ "2g2N");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "ofXK");








function ProjectComponent_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "span", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "a", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpropertyInterpolate1"]("href", "https://", ctx_r0.project.link, "", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx_r0.project.link, " ");
} }
function ProjectComponent_ng_container_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "span", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "i", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "p", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("Shutdown In ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](5, 1, ctx_r1.project.date, "dd/MM/yyyy"), "");
} }
function ProjectComponent_ng_container_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "i", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "p", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("Upcoming in ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](5, 1, ctx_r2.project.date, "dd/MM/yyyy"), "");
} }
function ProjectComponent_ng_container_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "i", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "p", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("Working on it until ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](5, 1, ctx_r3.project.date, "dd/MM/yyyy"), "");
} }
function ProjectComponent_li_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "li", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "i", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const framework_r5 = ctx.$implicit;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("title", ctx_r4.frameworks[framework_r5].title);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassMap"]("reset-icon icon-" + ctx_r4.frameworks[framework_r5].icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("innerHTML", ctx_r4.frameworks[framework_r5].innerHTML, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeHtml"]);
} }
class ProjectComponent {
    constructor(projectService, toastService, authService) {
        this.projectService = projectService;
        this.toastService = toastService;
        this.authService = authService;
        this.project = {
            priority: 0,
            title: '',
            date: new Date(),
            description: '',
            frameworks: [''],
            logoURL: '',
            status: 'development',
        };
        this.adminID = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__["environment"].adminID;
        this.frameworks = src_app_data_frameworks__WEBPACK_IMPORTED_MODULE_2__["FRAMEWORKS"];
    }
    ngOnInit() { }
    deleteCompany(PID) {
        if (this.isDeleting)
            return;
        this.isDeleting = PID;
        this.projectService
            .deleteProject(PID)
            .then((res) => {
            this.isDeleting = undefined;
            let toast = new src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__["Toast"]('project deleted', 'Project deleted successfully', 2);
            this.toastService.addToast(toast);
        })
            .catch((err) => {
            let toast = new src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__["Toast"]('error in deleting', 'error in deleting project', 2);
            this.toastService.addToast(toast);
            this.isDeleting = undefined;
        });
    }
}
ProjectComponent.ɵfac = function ProjectComponent_Factory(t) { return new (t || ProjectComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_services_projects_service__WEBPACK_IMPORTED_MODULE_4__["ProjectsService"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"])); };
ProjectComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: ProjectComponent, selectors: [["app-project"]], inputs: { project: "project" }, decls: 11, vars: 11, consts: [[1, "project-img"], [3, "src", "alt", "title"], [1, "project-description"], [4, "ngIf"], [1, "project-tools"], ["class", "pe-2", 3, "title", 4, "ngFor", "ngForOf"], ["title", "Production Mode", 1, "project-status-circle"], [1, "icon-launch"], ["target", "_blank", 1, "stretched-link", 3, "href"], ["title", "Shutdown Mode", 1, "project-status-circle"], [1, "icon-shut-down", "reset-icon"], [1, "project-status"], ["title", "Upcoming Mode", 1, "project-status-circle"], [1, "icon-new", "reset-icon"], ["title", "Development Mode", 1, "project-status-circle"], [1, "icon-repair", "reset-icon"], [1, "pe-2", 3, "title"], [3, "innerHTML"]], template: function ProjectComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "img", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "p", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](5, ProjectComponent_ng_container_5_Template, 5, 2, "ng-container", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](6, ProjectComponent_ng_container_6_Template, 6, 4, "ng-container", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](7, ProjectComponent_ng_container_7_Template, 6, 4, "ng-container", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](8, ProjectComponent_ng_container_8_Template, 6, 4, "ng-container", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "ul", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](10, ProjectComponent_li_10_Template, 2, 4, "li", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassMap"]("project card project-status-" + ctx.project.status);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", "assets/imgs/companies/" + ctx.project.logoURL, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"])("alt", ctx.project.title)("title", ctx.project.title);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx.project.description);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.project.status === "production");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.project.status === "shutdown");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.project.status === "upcoming");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.project.status === "development");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.project.frameworks);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_7__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["NgForOf"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_7__["DatePipe"]], styles: [".project[_ngcontent-%COMP%] {\n  --project-opacity: 1;\n  --project-color: var(--bs-primary);\n  padding: 60px 35px 30px;\n  text-align: center;\n  box-shadow: var(--nav-shadow);\n  border-radius: 12px;\n  border: 0;\n  max-width: 380px;\n  margin: auto;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-evenly;\n}\n.project-img[_ngcontent-%COMP%] {\n  max-width: 210px;\n  margin: 0 auto 20px;\n  height: auto;\n}\n.project-description[_ngcontent-%COMP%] {\n  margin-bottom: 20px;\n}\n.project-status[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 0;\n}\n.project-status[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  -webkit-padding-end: 10px;\n          padding-inline-end: 10px;\n}\n.project[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  font-size: 25px;\n}\n.project.project-status-shutdown[_ngcontent-%COMP%]   .project-status-circle[_ngcontent-%COMP%], .project.project-status-shutdown[_ngcontent-%COMP%]   .project-status[_ngcontent-%COMP%] {\n  --project-opacity: 0.4;\n  --project-color: var(--bs-red);\n}\n.project.project-status-development[_ngcontent-%COMP%]   .project-status-circle[_ngcontent-%COMP%], .project.project-status-development[_ngcontent-%COMP%]   .project-status[_ngcontent-%COMP%] {\n  --project-opacity: 0.6;\n  --project-color: var(--bs-yellow);\n}\n.project.project-status-upcoming[_ngcontent-%COMP%]   .project-status-circle[_ngcontent-%COMP%], .project.project-status-upcoming[_ngcontent-%COMP%]   .project-status[_ngcontent-%COMP%] {\n  --project-opacity: 0.8;\n  --project-color: var(--bs-secondary);\n}\n.project[_ngcontent-%COMP%]   .project-status-circle[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 20px;\n  left: 20px;\n  z-index: 50;\n  color: var(--project-color);\n  font-weight: 900;\n}\n.project[_ngcontent-%COMP%]   .project-status[_ngcontent-%COMP%] {\n  cursor: not-allowed;\n  opacity: var(--project-opacity);\n  color: var(--project-color);\n}\n.project[_ngcontent-%COMP%]   .project-status[_ngcontent-%COMP%]::-moz-selection {\n  background-color: var(--project-color);\n}\n.project[_ngcontent-%COMP%]   .project-status[_ngcontent-%COMP%]::selection {\n  background-color: var(--project-color);\n}\n.project-tools[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  top: 0;\n  list-style-type: none;\n  display: flex;\n  padding: 0;\n  z-index: 50;\n  padding: 15px 5px;\n  width: calc(100% - 50px);\n  overflow: auto;\n  flex-direction: row-reverse;\n}\n.project-tools[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  font-size: 35px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3QuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQkFBQTtFQUNBLGtDQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLDZCQUFBO0VBQ0EsbUJBQUE7RUFDQSxTQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLDZCQUFBO0FBQ0Y7QUFBRTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FBRUo7QUFBRTtFQUNFLG1CQUFBO0FBRUo7QUFBRTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7QUFFSjtBQURJO0VBQ0UseUJBQUE7VUFBQSx3QkFBQTtBQUdOO0FBQUU7RUFDRSxlQUFBO0FBRUo7QUFFSTs7RUFFRSxzQkFBQTtFQUNBLDhCQUFBO0FBQU47QUFLSTs7RUFFRSxzQkFBQTtFQUNBLGlDQUFBO0FBSE47QUFPSTs7RUFFRSxzQkFBQTtFQUNBLG9DQUFBO0FBTE47QUFTRTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsMkJBQUE7RUFDQSxnQkFBQTtBQVBKO0FBU0U7RUFDRSxtQkFBQTtFQUNBLCtCQUFBO0VBQ0EsMkJBQUE7QUFQSjtBQVFJO0VBQ0Usc0NBQUE7QUFOTjtBQUtJO0VBQ0Usc0NBQUE7QUFOTjtBQVVFO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsTUFBQTtFQUNBLHFCQUFBO0VBQ0EsYUFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSx3QkFBQTtFQUNBLGNBQUE7RUFDQSwyQkFBQTtBQVJKO0FBV007RUFDRSxlQUFBO0FBVFIiLCJmaWxlIjoicHJvamVjdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wcm9qZWN0IHtcbiAgLS1wcm9qZWN0LW9wYWNpdHk6IDE7XG4gIC0tcHJvamVjdC1jb2xvcjogdmFyKC0tYnMtcHJpbWFyeSk7XG4gIHBhZGRpbmc6IDYwcHggMzVweCAzMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJveC1zaGFkb3c6IHZhcigtLW5hdi1zaGFkb3cpO1xuICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICBib3JkZXI6IDA7XG4gIG1heC13aWR0aDogMzgwcHg7XG4gIG1hcmdpbjogYXV0bztcbiAgaGVpZ2h0OiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcbiAgJi1pbWcge1xuICAgIG1heC13aWR0aDogMjEwcHg7XG4gICAgbWFyZ2luOiAwIGF1dG8gMjBweDtcbiAgICBoZWlnaHQ6IGF1dG87XG4gIH1cbiAgJi1kZXNjcmlwdGlvbiB7XG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgfVxuICAmLXN0YXR1cyB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIG1hcmdpbi1ib3R0b206IDA7XG4gICAgaSB7XG4gICAgICBwYWRkaW5nLWlubGluZS1lbmQ6IDEwcHg7XG4gICAgfVxuICB9XG4gIGkge1xuICAgIGZvbnQtc2l6ZTogMjVweDtcbiAgfVxuXG4gICYucHJvamVjdC1zdGF0dXMtc2h1dGRvd24ge1xuICAgIC5wcm9qZWN0LXN0YXR1cy1jaXJjbGUsXG4gICAgLnByb2plY3Qtc3RhdHVzIHtcbiAgICAgIC0tcHJvamVjdC1vcGFjaXR5OiAwLjQ7XG4gICAgICAtLXByb2plY3QtY29sb3I6IHZhcigtLWJzLXJlZCk7XG4gICAgfVxuICB9XG5cbiAgJi5wcm9qZWN0LXN0YXR1cy1kZXZlbG9wbWVudCB7XG4gICAgLnByb2plY3Qtc3RhdHVzLWNpcmNsZSxcbiAgICAucHJvamVjdC1zdGF0dXMge1xuICAgICAgLS1wcm9qZWN0LW9wYWNpdHk6IDAuNjtcbiAgICAgIC0tcHJvamVjdC1jb2xvcjogdmFyKC0tYnMteWVsbG93KTtcbiAgICB9XG4gIH1cbiAgJi5wcm9qZWN0LXN0YXR1cy11cGNvbWluZyB7XG4gICAgLnByb2plY3Qtc3RhdHVzLWNpcmNsZSxcbiAgICAucHJvamVjdC1zdGF0dXMge1xuICAgICAgLS1wcm9qZWN0LW9wYWNpdHk6IDAuODtcbiAgICAgIC0tcHJvamVjdC1jb2xvcjogdmFyKC0tYnMtc2Vjb25kYXJ5KTtcbiAgICB9XG4gIH1cblxuICAucHJvamVjdC1zdGF0dXMtY2lyY2xlIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAyMHB4O1xuICAgIGxlZnQ6IDIwcHg7XG4gICAgei1pbmRleDogNTA7XG4gICAgY29sb3I6IHZhcigtLXByb2plY3QtY29sb3IpO1xuICAgIGZvbnQtd2VpZ2h0OiA5MDA7XG4gIH1cbiAgLnByb2plY3Qtc3RhdHVzIHtcbiAgICBjdXJzb3I6IG5vdC1hbGxvd2VkO1xuICAgIG9wYWNpdHk6IHZhcigtLXByb2plY3Qtb3BhY2l0eSk7XG4gICAgY29sb3I6IHZhcigtLXByb2plY3QtY29sb3IpO1xuICAgICY6OnNlbGVjdGlvbiB7XG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wcm9qZWN0LWNvbG9yKTtcbiAgICB9XG4gIH1cblxuICAmLXRvb2xzIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgcmlnaHQ6IDA7XG4gICAgdG9wOiAwO1xuICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHBhZGRpbmc6IDA7XG4gICAgei1pbmRleDogNTA7XG4gICAgcGFkZGluZzogMTVweCA1cHg7XG4gICAgd2lkdGg6IGNhbGMoMTAwJSAtIDUwcHgpO1xuICAgIG92ZXJmbG93OiBhdXRvO1xuICAgIGZsZXgtZGlyZWN0aW9uOiByb3ctcmV2ZXJzZTtcblxuICAgIGxpIHtcbiAgICAgIGkge1xuICAgICAgICBmb250LXNpemU6IDM1cHg7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iXX0= */"] });


/***/ }),

/***/ "Lby2":
/*!*******************************************!*\
  !*** ./src/app/core/toast/Toast.model.ts ***!
  \*******************************************/
/*! exports provided: Toast */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Toast", function() { return Toast; });
/**
 * Generate new Toast message with Toast type
 * @constructor
 * @param {string} header - Identify the header of the Toast
 * @param {string} message - Identify the message of the Toast
 * @param {number} typeCode - Identify the Code of the type of the Toast 1 => primary, 2 => secondry, 3 => danger, 4 => warning, 5 => info, 6 => dark
 * @function type -> to get the type of the Toast as string
 *
 */
class Toast {
    constructor(header, message, typeCode) {
        this.header = header;
        this.message = message;
        this.typeCode = typeCode;
    }
    get type() {
        let color;
        if (this.typeCode === 1) {
            color = 'primary';
        }
        else if (this.typeCode === 2) {
            color = 'secondary';
        }
        else if (this.typeCode === 3) {
            color = 'tertiary';
        }
        else if (this.typeCode === 4) {
            color = 'danger';
        }
        else if (this.typeCode === 5) {
            color = 'success';
        }
        else if (this.typeCode === 6) {
            color = 'warning';
        }
        else if (this.typeCode) {
            color = 'dark';
        }
        else {
            color = 'white';
        }
        return color;
    }
}


/***/ }),

/***/ "Na6d":
/*!**********************************************************************!*\
  !*** ./src/app/core/modals/add-testimonial/add-testimonial.modal.ts ***!
  \**********************************************************************/
/*! exports provided: AddTestimonialModal */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddTestimonialModal", function() { return AddTestimonialModal; });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../toast/Toast.model */ "Lby2");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var src_app_services_testimonials_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/testimonials.service */ "Z9jq");
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/toast.service */ "2g2N");
/* harmony import */ var _shared_components_user_account_user_account_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/components/user-account/user-account.component */ "bT90");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "ofXK");









function AddTestimonialModal_span_27_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Say It");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function AddTestimonialModal_span_28_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Flying...");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
class AddTestimonialModal {
    constructor(fb, authService, testimonialsService, toastService) {
        this.fb = fb;
        this.authService = authService;
        this.testimonialsService = testimonialsService;
        this.toastService = toastService;
        this.user = null;
        this.testimonialForm = this.fb.group({
            position: [''],
            message: [
                '',
                [
                    _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].minLength(3),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].maxLength(1000),
                ],
            ],
        });
        this.isSending = false;
    }
    get position() {
        return this.testimonialForm.get('position');
    }
    get message() {
        return this.testimonialForm.get('message');
    }
    ngOnInit() {
        this.userSubs();
    }
    userSubs() {
        this.authService.user$.subscribe((user) => (this.user = user));
    }
    onSendForm() {
        if (this.testimonialForm.invalid)
            return;
        this.isSending = true;
        this.testimonialForm.disable();
        if (!this.user)
            return;
        let testimonialForm = {
            uid: this.user.uid,
            position: this.position.value,
            message: this.message.value,
            approved: false,
        };
        this.testimonialsService.addTestimonial(testimonialForm).then((res) => {
            let toast = new _toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__["Toast"]('message sent successfully', 'Thank You, I just recieved your testimonial', 2);
            this.toastService.addToast(toast);
            this.isSending = false;
            this.resetForm();
            this.testimonialForm.enable();
        }, (err) => {
            let toast = new _toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__["Toast"]('Error', 'There is an error in sending your testimonial', 2);
            this.toastService.addToast(toast);
            this.isSending = false;
            this.testimonialForm.enable();
        });
    }
    resetForm() {
        this.testimonialForm.reset({
            position: '',
            message: '',
        });
    }
}
AddTestimonialModal.ɵfac = function AddTestimonialModal_Factory(t) { return new (t || AddTestimonialModal)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_testimonials_service__WEBPACK_IMPORTED_MODULE_4__["TestimonialsService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"])); };
AddTestimonialModal.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: AddTestimonialModal, selectors: [["modal-add-testimonial"]], decls: 30, vars: 14, consts: [["id", "testimonialModal", "tabindex", "-1", "aria-labelledby", "testimonialModalLabel", "aria-hidden", "true", 1, "modal", "fade"], [1, "modal-dialog", "modal-fullscreen"], [1, "modal-content"], [1, "modal-body"], [1, "d-flex", "justify-content-between", "align-items-center", "border-0"], ["src", "assets/imgs/logo/omar-logo.png", "alt", "omar logo", "width", "80px"], [1, "text-center"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn", "icon-cancel"], ["id", "testimonialForm", 1, "row", "say-hello-form", 3, "formGroup", "ngSubmit"], [1, "col-12"], [1, "form-floating", "mb-4"], ["id", "position", "type", "tel", "formControlName", "position", "placeholder", "Sr. System Developers, Domain7", 1, "form-control"], ["for", "position"], ["id", "message", "formControlName", "message", "placeholder", "tell me <3", 1, "form-control", "form-control-lg", 2, "min-height", "190px"], ["for", "message", 1, "form-label"], [1, "invalid-feedback"], [1, "modal-footer", "border-0", "justify-content-center"], ["type", "submit", "form", "testimonialForm", 1, "btn", "btn-secondary", "rounded-pill", "btn-lg", "px-5", "d-flex", "align-items-center", 3, "disabled"], [4, "ngIf"], [1, "reset-icon", "ms-2"]], template: function AddTestimonialModal_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "img", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "h2", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](8, "Tell people about our time!");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](9, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](10, "form", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngSubmit", function AddTestimonialModal_Template_form_ngSubmit_10_listener() { return ctx.onSendForm(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](12, "app-user-account");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](15, "input", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](17, "your position (not required) ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](20, "textarea", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](21, "label", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](22, " Say it to the world <3 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](23, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](24, "hey! you have to say it");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](25, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](26, "button", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](27, AddTestimonialModal_span_27_Template, 2, 0, "span", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](28, AddTestimonialModal_span_28_Template, 2, 0, "span", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](29, "i", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx.testimonialForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("is-invalid", ctx.position.invalid && ctx.position.touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("is-invalid", ctx.message.invalid && ctx.message.touched)("is-valid", ctx.message.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx.testimonialForm.invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.isSending);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.isSending);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("icon-send", !ctx.isSending)("icon-sending", ctx.isSending);
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_0__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormGroupDirective"], _shared_components_user_account_user_account_component__WEBPACK_IMPORTED_MODULE_6__["UserAccountComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormControlName"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["NgIf"]], styles: [".say-hello-form[_ngcontent-%COMP%] {\n  max-width: 500px;\n  margin: auto;\n  padding: 30px 15px 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2FkZC10ZXN0aW1vbmlhbC5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7QUFDRiIsImZpbGUiOiJhZGQtdGVzdGltb25pYWwubW9kYWwuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zYXktaGVsbG8tZm9ybSB7XG4gIG1heC13aWR0aDogNTAwcHg7XG4gIG1hcmdpbjogYXV0bztcbiAgcGFkZGluZzogMzBweCAxNXB4IDE1cHg7XG59XG4iXX0= */"] });


/***/ }),

/***/ "PCNd":
/*!*****************************************!*\
  !*** ./src/app/shared/shared.module.ts ***!
  \*****************************************/
/*! exports provided: SharedModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedModule", function() { return SharedModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @sweetalert2/ngx-sweetalert2 */ "QJFE");
/* harmony import */ var _components_company_company_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/company/company.component */ "gBp8");
/* harmony import */ var _components_project_project_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/project/project.component */ "ImyP");
/* harmony import */ var _components_user_account_user_account_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/user-account/user-account.component */ "bT90");
/* harmony import */ var _components_tools_svg_tools_svg_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/tools-svg/tools-svg.component */ "whMB");
/* harmony import */ var _components_team_team_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/team/team.component */ "pPLs");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ "fXoL");








const SharedModules = [
    _components_company_company_component__WEBPACK_IMPORTED_MODULE_2__["CompanyComponent"],
    _components_project_project_component__WEBPACK_IMPORTED_MODULE_3__["ProjectComponent"],
    _components_user_account_user_account_component__WEBPACK_IMPORTED_MODULE_4__["UserAccountComponent"],
    _components_tools_svg_tools_svg_component__WEBPACK_IMPORTED_MODULE_5__["ToolsSvgComponent"],
    _components_team_team_component__WEBPACK_IMPORTED_MODULE_6__["TeamComponent"],
];
class SharedModule {
}
SharedModule.ɵfac = function SharedModule_Factory(t) { return new (t || SharedModule)(); };
SharedModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({ type: SharedModule });
SharedModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"], _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_1__["SweetAlert2Module"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](SharedModule, { declarations: [_components_company_company_component__WEBPACK_IMPORTED_MODULE_2__["CompanyComponent"],
        _components_project_project_component__WEBPACK_IMPORTED_MODULE_3__["ProjectComponent"],
        _components_user_account_user_account_component__WEBPACK_IMPORTED_MODULE_4__["UserAccountComponent"],
        _components_tools_svg_tools_svg_component__WEBPACK_IMPORTED_MODULE_5__["ToolsSvgComponent"],
        _components_team_team_component__WEBPACK_IMPORTED_MODULE_6__["TeamComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"], _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_1__["SweetAlert2Module"]], exports: [_components_company_company_component__WEBPACK_IMPORTED_MODULE_2__["CompanyComponent"],
        _components_project_project_component__WEBPACK_IMPORTED_MODULE_3__["ProjectComponent"],
        _components_user_account_user_account_component__WEBPACK_IMPORTED_MODULE_4__["UserAccountComponent"],
        _components_tools_svg_tools_svg_component__WEBPACK_IMPORTED_MODULE_5__["ToolsSvgComponent"],
        _components_team_team_component__WEBPACK_IMPORTED_MODULE_6__["TeamComponent"]] }); })();


/***/ }),

/***/ "R2Se":
/*!*************************************************!*\
  !*** ./src/app/core/navbar/navbar.component.ts ***!
  \*************************************************/
/*! exports provided: NavbarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavbarComponent", function() { return NavbarComponent; });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ "AytR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_app_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/app.service */ "F5nt");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "ofXK");






function NavbarComponent_i_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "i", 19);
} }
function NavbarComponent_i_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "i", 20);
} }
function NavbarComponent_ng_container_12_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "img", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](4, "titlecase");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "ul", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "li", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](7, "img", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](8, "titlecase");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "h5");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](12, "titlecase");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "button", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NavbarComponent_ng_container_12_Template_button_click_16_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r7.signOut(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](17, "Signout");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const user_r6 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", user_r6.photoURL, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"])("title", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](4, 8, user_r6.displayName))("alt", user_r6.displayName);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", user_r6.photoURL, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"])("title", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](8, 10, user_r6.displayName))("alt", user_r6.displayName);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](12, 12, user_r6.displayName));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](user_r6.email);
} }
function NavbarComponent_ng_template_14_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NavbarComponent_ng_template_14_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r9.onLogin(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "i", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function NavbarComponent_ng_container_21_li_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "a", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const link_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("routerLink", link_r11.url);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](link_r11.title);
} }
function NavbarComponent_ng_container_21_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, NavbarComponent_ng_container_21_li_1_Template, 3, 2, "li", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const link_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", link_r11.isActive);
} }
class NavbarComponent {
    constructor(appService, authService) {
        this.appService = appService;
        this.authService = authService;
        this.user = null;
        this.isDarkMode = false;
        this.isMenuOpened = false;
        this.links = [];
        this.sub$ = [];
    }
    ngOnInit() {
        this.initLinks();
        this.sub$.push(this.appService.isDarkMode$.subscribe((v) => (this.isDarkMode = v)), this.authService.user$.subscribe((user) => {
            this.user = user;
            this.initLinks();
        }));
    }
    initLinks() {
        this.links = [
            { title: 'Home', url: '/', isActive: true },
            { title: 'About', url: '/about', isActive: false },
            { title: 'Services', url: '/services', isActive: false },
            { title: 'Portfolio', url: '/portfolio', isActive: false },
            { title: 'Companies', url: '/companies', isActive: false },
            { title: 'Testimonials', url: '/testimonials', isActive: false },
            { title: 'Contact Me', url: '/contact-me', isActive: false },
            // { title: 'Privacy Policy', url: '/privacy-policy', isActive: true },
            {
                title: 'DB Companies',
                url: '/dashboard/companies',
                isActive: this.isAdmin(),
            },
            {
                title: 'DB Projects',
                url: '/dashboard/projects',
                isActive: this.isAdmin(),
            },
            { title: 'DB Users', url: '/dashboard/users', isActive: this.isAdmin() },
            {
                title: 'DB Testimonials',
                url: '/dashboard/testimonials',
                isActive: this.isAdmin(),
            },
            { title: 'DB Team', url: '/dashboard/team', isActive: this.isAdmin() },
        ];
    }
    onLogin() {
        this.authService.showOneTapGoogle();
    }
    signOut() {
        this.authService.signOut();
    }
    switchMode() {
        this.appService.switchMode();
    }
    isAdmin() {
        var _a;
        return ((_a = this.user) === null || _a === void 0 ? void 0 : _a.uid) === src_environments_environment__WEBPACK_IMPORTED_MODULE_0__["environment"].adminID;
    }
    ngOnDestroy() {
        this.sub$.forEach((subs) => subs.unsubscribe());
    }
}
NavbarComponent.ɵfac = function NavbarComponent_Factory(t) { return new (t || NavbarComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_app_service__WEBPACK_IMPORTED_MODULE_2__["AppService"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"])); };
NavbarComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: NavbarComponent, selectors: [["app-navbar"]], decls: 22, vars: 7, consts: [[1, "navbar", "navbar-light", "fixed-top", "p-0"], [1, "navbar-container", "container-fluid", "p-0"], [1, "wow", "animate__animated", "animate__fadeInDown"], ["routerLink", "/", 1, "navbar-brand", "d-block"], ["src", "assets/imgs/logo/fatma.jpg", "alt", "omar logo", "width", "80px"], [1, "navbar-menu", "wow", "animate__animated", "animate__slideInRight"], [1, "navbar-action"], ["data-bs-toggle", "modal", "data-bs-target", "#sayHelloModal", 1, "call-to-action-btn", "btn-outline-primary", "btn"], [1, "nav-btn", "btn", 3, "click"], ["class", "icon-moon", 4, "ngIf"], ["class", "icon-sun", 4, "ngIf"], [4, "ngIf", "ngIfElse"], ["guest", ""], [1, "dropdown", "menu-dropdown"], ["type", "button", "id", "nav-list", "data-bs-toggle", "dropdown", "aria-expanded", "false", 1, "nav-btn", "btn", "dropdown-toggle"], [1, "icon-ellipsis"], [1, "icon-cancel"], ["aria-labelledby", "nav-list", 1, "dropdown-menu", "dropdown-menu-end", "navbar-list", "animate__animated", "animate__zoomIn"], [4, "ngFor", "ngForOf"], [1, "icon-moon"], [1, "icon-sun"], [1, "dropdown", "user-dropdown"], ["type", "button", "id", "googleDropdown", "data-bs-toggle", "dropdown", "aria-expanded", "false", 1, "btn", "nav-btn", "dropdown-toggle"], [1, "img-fluid", "rounded-circle", 3, "src", "title", "alt"], ["aria-labelledby", "googleDropdown", 1, "dropdown-menu", "dropdown-menu-end", "text-center", "p-4", "mt-2", "animate__animated", "animate__zoomIn"], [1, "pb-3"], [1, "rounded-circle", 3, "src", "title", "alt"], [1, "btn", "btn-danger", "mt-3", 3, "click"], [1, "icon-google-plus"], [4, "ngIf"], [3, "routerLink"]], template: function NavbarComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "nav", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "a", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8, "Say Hello");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NavbarComponent_Template_button_click_9_listener() { return ctx.switchMode(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](10, NavbarComponent_i_10_Template, 1, 0, "i", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, NavbarComponent_i_11_Template, 1, 0, "i", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](12, NavbarComponent_ng_container_12_Template, 18, 14, "ng-container", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](13, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](14, NavbarComponent_ng_template_14_Template, 2, 0, "ng-template", null, 12, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](18, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](19, "i", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "ul", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](21, NavbarComponent_ng_container_21_Template, 2, 1, "ng-container", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", !ctx.isDarkMode);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.isDarkMode);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](13, 5, ctx.authService.user$))("ngIfElse", _r3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.links);
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterLinkWithHref"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgForOf"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_5__["AsyncPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["TitleCasePipe"]], styles: [".navbar[_ngcontent-%COMP%] {\n  background-image: unset;\n  max-height: 0px;\n}\n.navbar[_ngcontent-%COMP%]   .navbar-container[_ngcontent-%COMP%] {\n  max-height: 0px;\n}\n@media screen and (max-width: 450px) {\n  .navbar[_ngcontent-%COMP%]   .navbar-container[_ngcontent-%COMP%] {\n    align-items: start;\n  }\n}\n.navbar[_ngcontent-%COMP%]   .navbar-brand[_ngcontent-%COMP%] {\n  -webkit-padding-start: 20px;\n          padding-inline-start: 20px;\n  margin-right: 0rem;\n}\n@media screen and (max-width: 450px) {\n  .navbar[_ngcontent-%COMP%]   .navbar-brand[_ngcontent-%COMP%] {\n    padding: 0;\n    -webkit-padding-start: 10px;\n            padding-inline-start: 10px;\n  }\n  .navbar[_ngcontent-%COMP%]   .navbar-brand[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n    width: 45px;\n  }\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%] {\n  position: relative;\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .navbar-action[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  align-items: stretch;\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .navbar-action[_ngcontent-%COMP%]   .dropdown-toggle[_ngcontent-%COMP%]::after {\n  display: none;\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .navbar-action[_ngcontent-%COMP%]   .nav-btn[_ngcontent-%COMP%] {\n  width: 65px;\n  height: 65px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border-radius: 0;\n  background-color: var(--nav-bg);\n  box-shadow: var(--nav-shadow);\n  color: var(--dark);\n  border-radius: 0%;\n  transition: all 300ms ease-in-out;\n  position: relative;\n}\n@media screen and (max-width: 450px) {\n  .navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .navbar-action[_ngcontent-%COMP%]   .nav-btn[_ngcontent-%COMP%] {\n    width: 55px;\n    height: 45px;\n  }\n  .navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .navbar-action[_ngcontent-%COMP%]   .nav-btn[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n    font-size: 1.5rem;\n  }\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .navbar-action[_ngcontent-%COMP%]   .nav-btn[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  display: block;\n  transition: transform 500ms;\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .navbar-action[_ngcontent-%COMP%]   .nav-btn[_ngcontent-%COMP%]:hover   i[_ngcontent-%COMP%] {\n  transform: scale(1.2);\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .navbar-action[_ngcontent-%COMP%]   .call-to-action-btn[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border-bottom-left-radius: 40%;\n  box-shadow: var(--nav-shadow);\n  background-color: var(--nav-bg);\n  color: #ff8da1;\n  border-color: #ff8da1;\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .navbar-action[_ngcontent-%COMP%]   .call-to-action-btn[_ngcontent-%COMP%]:hover {\n  background-color: white;\n  border-color: white;\n}\n@media (max-width: 450px) {\n  .navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .navbar-action[_ngcontent-%COMP%]   .call-to-action-btn[_ngcontent-%COMP%] {\n    border-radius: 0;\n    border-bottom-left-radius: 8px;\n  }\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .navbar-action[_ngcontent-%COMP%]   .logout-link[_ngcontent-%COMP%], .navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .navbar-action[_ngcontent-%COMP%]   .logout-link[_ngcontent-%COMP%]:hover {\n  color: var(--bs-danger);\n  background-color: unset;\n  background-image: unset;\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .menu-dropdown[_ngcontent-%COMP%]   .dropdown-toggle[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  display: none;\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .menu-dropdown[_ngcontent-%COMP%]   .dropdown-toggle[_ngcontent-%COMP%]   i.icon-ellipsis[_ngcontent-%COMP%] {\n  display: block;\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .menu-dropdown[_ngcontent-%COMP%]   .dropdown-toggle.show[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  display: block;\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .menu-dropdown[_ngcontent-%COMP%]   .dropdown-toggle.show[_ngcontent-%COMP%]   i.icon-ellipsis[_ngcontent-%COMP%] {\n  display: none;\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .menu-dropdown[_ngcontent-%COMP%]   .navbar-list[_ngcontent-%COMP%] {\n  color: #fff;\n  width: 220px;\n  text-align: center;\n  background-color: unset;\n  border: unset;\n}\n.navbar[_ngcontent-%COMP%]   .navbar-menu[_ngcontent-%COMP%]   .menu-dropdown[_ngcontent-%COMP%]   .navbar-list[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  background-color: var(--bs-secondary);\n  margin: 5px 0;\n  padding: 10px 20px;\n  border-radius: 40px;\n  color: #fff;\n  display: inline-block;\n}\n.navbar-brand[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  border-radius: 50%;\n}\n[class^=icon-][_ngcontent-%COMP%] {\n  color: #ff8da1;\n  -webkit-text-fill-color: unset;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL25hdmJhci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHVCQUFBO0VBQ0EsZUFBQTtBQUNGO0FBQUU7RUFDRSxlQUFBO0FBRUo7QUFBSTtFQUhGO0lBSUksa0JBQUE7RUFHSjtBQUNGO0FBREU7RUFDRSwyQkFBQTtVQUFBLDBCQUFBO0VBQ0Esa0JBQUE7QUFHSjtBQUZJO0VBSEY7SUFJSSxVQUFBO0lBQ0EsMkJBQUE7WUFBQSwwQkFBQTtFQUtKO0VBSkk7SUFDRSxXQUFBO0VBTU47QUFDRjtBQUhFO0VBQ0Usa0JBQUE7QUFLSjtBQUpJO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0Esb0JBQUE7QUFNTjtBQUxNO0VBQ0UsYUFBQTtBQU9SO0FBTE07RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSwrQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGlDQUFBO0VBQ0Esa0JBQUE7QUFPUjtBQU5RO0VBYkY7SUFjSSxXQUFBO0lBQ0EsWUFBQTtFQVNSO0VBUlE7SUFDRSxpQkFBQTtFQVVWO0FBQ0Y7QUFSUTtFQUNFLGNBQUE7RUFDQSwyQkFBQTtBQVVWO0FBUlE7RUFDRSxxQkFBQTtBQVVWO0FBUE07RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0VBQ0EsNkJBQUE7RUFDQSwrQkFBQTtFQUNBLGNBQUE7RUFDQSxxQkFBQTtBQVNSO0FBUlE7RUFDRSx1QkFBQTtFQUNBLG1CQUFBO0FBVVY7QUFSUTtFQWJGO0lBY0ksZ0JBQUE7SUFDQSw4QkFBQTtFQVdSO0FBQ0Y7QUFUTTs7RUFFRSx1QkFBQTtFQUNBLHVCQUFBO0VBQ0EsdUJBQUE7QUFXUjtBQU5RO0VBQ0UsYUFBQTtBQVFWO0FBUFU7RUFDRSxjQUFBO0FBU1o7QUFMVTtFQUNFLGNBQUE7QUFPWjtBQUxVO0VBQ0UsYUFBQTtBQU9aO0FBSE07RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxhQUFBO0FBS1I7QUFKUTtFQUNFLHFDQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7QUFNVjtBQUVBO0VBQ0Usa0JBQUE7QUFDRjtBQUVBO0VBQ0MsY0FBQTtFQUVHLDhCQUFBO0FBQUoiLCJmaWxlIjoibmF2YmFyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm5hdmJhciB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVuc2V0O1xuICBtYXgtaGVpZ2h0OiAwcHg7XG4gIC5uYXZiYXItY29udGFpbmVyIHtcbiAgICBtYXgtaGVpZ2h0OiAwcHg7XG5cbiAgICBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA0NTBweCkge1xuICAgICAgYWxpZ24taXRlbXM6IHN0YXJ0O1xuICAgIH1cbiAgfVxuICAubmF2YmFyLWJyYW5kIHtcbiAgICBwYWRkaW5nLWlubGluZS1zdGFydDogMjBweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDByZW07XG4gICAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDUwcHgpIHtcbiAgICAgIHBhZGRpbmc6IDA7XG4gICAgICBwYWRkaW5nLWlubGluZS1zdGFydDogMTBweDtcbiAgICAgIGltZyB7XG4gICAgICAgIHdpZHRoOiA0NXB4O1xuICAgICAgfVxuICAgIH1cbiAgfVxuICAubmF2YmFyLW1lbnUge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAubmF2YmFyLWFjdGlvbiB7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICBhbGlnbi1pdGVtczogc3RyZXRjaDtcbiAgICAgIC5kcm9wZG93bi10b2dnbGU6OmFmdGVyIHtcbiAgICAgICAgZGlzcGxheTogbm9uZTtcbiAgICAgIH1cbiAgICAgIC5uYXYtYnRuIHtcbiAgICAgICAgd2lkdGg6IDY1cHg7XG4gICAgICAgIGhlaWdodDogNjVweDtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDA7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLW5hdi1iZyk7XG4gICAgICAgIGJveC1zaGFkb3c6IHZhcigtLW5hdi1zaGFkb3cpO1xuICAgICAgICBjb2xvcjogdmFyKC0tZGFyayk7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDAlO1xuICAgICAgICB0cmFuc2l0aW9uOiBhbGwgMzAwbXMgZWFzZS1pbi1vdXQ7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDUwcHgpIHtcbiAgICAgICAgICB3aWR0aDogNTVweDtcbiAgICAgICAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgICAgICAgaSB7XG4gICAgICAgICAgICBmb250LXNpemU6IDEuNXJlbTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaSB7XG4gICAgICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICAgICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDUwMG1zO1xuICAgICAgICB9XG4gICAgICAgICY6aG92ZXIgaSB7XG4gICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICAuY2FsbC10by1hY3Rpb24tYnRuIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDQwJTtcbiAgICAgICAgYm94LXNoYWRvdzogdmFyKC0tbmF2LXNoYWRvdyk7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLW5hdi1iZyk7XG4gICAgICAgIGNvbG9yOiAjZmY4ZGExO1xuICAgICAgICBib3JkZXItY29sb3I6I2ZmOGRhMSA7XG4gICAgICAgICY6aG92ZXIge1xuICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICAgICAgICAgIGJvcmRlci1jb2xvcjogd2hpdGU7XG4gICAgICAgIH1cbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDQ1MHB4KSB7XG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogMDtcbiAgICAgICAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA4cHg7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC5sb2dvdXQtbGluayxcbiAgICAgIC5sb2dvdXQtbGluazpob3ZlciB7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1icy1kYW5nZXIpO1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB1bnNldDtcbiAgICAgICAgYmFja2dyb3VuZC1pbWFnZTogdW5zZXQ7XG4gICAgICB9XG4gICAgfVxuICAgIC5tZW51LWRyb3Bkb3duIHtcbiAgICAgIC5kcm9wZG93bi10b2dnbGUge1xuICAgICAgICBpIHtcbiAgICAgICAgICBkaXNwbGF5OiBub25lO1xuICAgICAgICAgICYuaWNvbi1lbGxpcHNpcyB7XG4gICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgJi5zaG93IHtcbiAgICAgICAgICBpIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpLmljb24tZWxsaXBzaXMge1xuICAgICAgICAgICAgZGlzcGxheTogbm9uZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC5uYXZiYXItbGlzdCB7XG4gICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICB3aWR0aDogMjIwcHg7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdW5zZXQ7XG4gICAgICAgIGJvcmRlcjogdW5zZXQ7XG4gICAgICAgIGEge1xuICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWJzLXNlY29uZGFyeSk7XG4gICAgICAgICAgbWFyZ2luOiA1cHggMDtcbiAgICAgICAgICBwYWRkaW5nOiAxMHB4IDIwcHg7XG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogNDBweDtcbiAgICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuXG4ubmF2YmFyLWJyYW5kIGltZyB7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cblxuW2NsYXNzXj1pY29uLV0ge1xuIGNvbG9yOiAjZmY4ZGExO1xuXG4gICAgLXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IHVuc2V0O1xuXG59IFxuIl19 */"] });


/***/ }),

/***/ "Sy1n":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var bootstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap */ "exfh");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.service */ "F5nt");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./auth/auth.service */ "qXBG");
/* harmony import */ var _core_splash_screen_splash_screen_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./core/splash-screen/splash-screen.service */ "y4qi");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _core_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./core/navbar/navbar.component */ "R2Se");
/* harmony import */ var ng2_adsense__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ng2-adsense */ "Cvm2");
/* harmony import */ var _core_footer_footer_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./core/footer/footer.component */ "FxTl");
/* harmony import */ var _core_toast_toast_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./core/toast/toast.component */ "2hTU");
/* harmony import */ var _core_modals_conversation_conversation_modal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./core/modals/conversation/conversation.modal */ "Zewy");
/* harmony import */ var _core_modals_say_hello_say_hello_modal__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./core/modals/say-hello/say-hello.modal */ "EvY5");
/* harmony import */ var _core_modals_add_testimonial_add_testimonial_modal__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./core/modals/add-testimonial/add-testimonial.modal */ "Na6d");
/* harmony import */ var _core_modals_join_team_join_team_modal__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./core/modals/join-team/join-team.modal */ "7fBr");
















function AppComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "nav", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](3, "app-navbar");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "main", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](5, "router-outlet");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "ng-adsense", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "footer", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](8, "app-footer");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](9, "app-toast");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](10, "modal-conversation");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](11, "modal-say-hello");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](12, "modal-add-testimonial");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](13, "modal-join-team");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} }
class AppComponent {
    constructor(appService, authService, router, splashScreenService) {
        this.appService = appService;
        this.authService = authService;
        this.router = router;
        this.splashScreenService = splashScreenService;
        this.sub$ = [];
        this.showApp = false;
    }
    ngOnInit() {
        this.appService.initWOW();
        this.initBootstrap();
        const routerSub$ = this.router.events.subscribe((event) => {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_0__["NavigationEnd"]) {
                // hide splash screen
                this.splashScreenService.hide();
                // scroll to top on every route change
                window.scrollTo(0, 0);
                // to display back the body content
                setTimeout(() => {
                    document.body.classList.add('page-loaded');
                    document.body.classList.remove('page-loading');
                    this.showApp = true;
                }, 1500);
            }
        });
        this.sub$.push(routerSub$);
    }
    initBootstrap() {
        let el;
        new bootstrap__WEBPACK_IMPORTED_MODULE_1__["Modal"](el);
    }
    ngOnDestroy() {
        this.sub$.forEach((sb) => sb.unsubscribe());
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_app_service__WEBPACK_IMPORTED_MODULE_3__["AppService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_0__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_core_splash_screen_splash_screen_service__WEBPACK_IMPORTED_MODULE_5__["SplashScreenService"])); };
AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "main-wrapper"], [1, "navbar-wrapper"], [1, "content-wrapper"], ["data-ad-format", "auto", "data-full-width-responsive", "true", 1, "adsbygoogle", 2, "display", "none"], [1, "footer-wrapper"]], template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](0, AppComponent_ng_container_0_Template, 14, 0, "ng-container", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.showApp);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["NgIf"], _core_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_7__["NavbarComponent"], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterOutlet"], ng2_adsense__WEBPACK_IMPORTED_MODULE_8__["AdsenseComponent"], _core_footer_footer_component__WEBPACK_IMPORTED_MODULE_9__["FooterComponent"], _core_toast_toast_component__WEBPACK_IMPORTED_MODULE_10__["ToastComponent"], _core_modals_conversation_conversation_modal__WEBPACK_IMPORTED_MODULE_11__["ConversationModal"], _core_modals_say_hello_say_hello_modal__WEBPACK_IMPORTED_MODULE_12__["SayHelloModal"], _core_modals_add_testimonial_add_testimonial_modal__WEBPACK_IMPORTED_MODULE_13__["AddTestimonialModal"], _core_modals_join_team_join_team_modal__WEBPACK_IMPORTED_MODULE_14__["JoinTeamComponent"]], styles: [".main-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  min-height: 100vh;\n}\n.main-wrapper[_ngcontent-%COMP%]   .content-wrapper[_ngcontent-%COMP%] {\n  min-height: 100vh;\n}\n.main-wrapper[_ngcontent-%COMP%]   .footer-wrapper[_ngcontent-%COMP%] {\n  margin-top: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL2FwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0FBQ0Y7QUFDRTtFQUNFLGlCQUFBO0FBQ0o7QUFDRTtFQUNFLGdCQUFBO0FBQ0oiLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1haW4td3JhcHBlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIG1pbi1oZWlnaHQ6IDEwMHZoO1xuXG4gIC5jb250ZW50LXdyYXBwZXIge1xuICAgIG1pbi1oZWlnaHQ6IDEwMHZoO1xuICB9XG4gIC5mb290ZXItd3JhcHBlciB7XG4gICAgbWFyZ2luLXRvcDogYXV0bztcbiAgfVxufVxuIl19 */"] });


/***/ }),

/***/ "YI7L":
/*!************************************!*\
  !*** ./src/app/data/frameworks.ts ***!
  \************************************/
/*! exports provided: FRAMEWORKS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FRAMEWORKS", function() { return FRAMEWORKS; });
const FRAMEWORKS = {
    wordpress: {
        title: 'Wordpress',
        icon: 'wordpress',
        innerHTML: '',
    },
    woocommerce: {
        title: 'Woocommerce',
        icon: 'woocommerce',
        innerHTML: '<span class="path1"></span><span class="path2"></span>',
    },
    laravel: {
        title: 'Laravel',
        icon: 'laravel',
        innerHTML: '',
    },
    angular: {
        title: 'Angular',
        icon: 'angular',
        innerHTML: '<span class="path1"></span><span class="path2"></span><span class="path3"></span>',
    },
    ionic: {
        title: 'Ionic',
        icon: 'ionic',
        innerHTML: '',
    },
    nodejs: {
        title: 'Nodejs',
        icon: 'nodejs',
        innerHTML: '<span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span><span class="path9"></span><span class="path10"></span>',
    },
    php: {
        title: 'PHP',
        icon: 'php',
        innerHTML: '<span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span>',
    },
    pwa: {
        title: 'PWA',
        icon: 'pwa',
        innerHTML: '<span class="path1"></span><span class="path2"></span><span class="path3"></span>',
    },
};


/***/ }),

/***/ "Z9jq":
/*!**************************************************!*\
  !*** ./src/app/services/testimonials.service.ts ***!
  \**************************************************/
/*! exports provided: TestimonialsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestimonialsService", function() { return TestimonialsService; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");
/* harmony import */ var _users_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./users.service */ "6Qg2");





class TestimonialsService {
    constructor(firestore, usersService) {
        this.firestore = firestore;
        this.usersService = usersService;
        this.testimonials = new rxjs__WEBPACK_IMPORTED_MODULE_0__["BehaviorSubject"]([]);
        this.testiCollection = this.firestore.collection('testimonial');
        this.combineUsersWithTestimonials();
    }
    combineUsersWithTestimonials() {
        let users = this.usersService.getUsers();
        let testimonials = this.getTestimonials();
        let res = Object(rxjs__WEBPACK_IMPORTED_MODULE_0__["combineLatest"])([users, testimonials]);
        res.subscribe((res) => {
            let users = res[0];
            let testimonials = [];
            res[1].forEach((testi) => {
                let user = users.find((u) => u.uid === testi.uid);
                if (!user)
                    return;
                testimonials.push(Object.assign(Object.assign({}, testi), { user }));
            });
            this.testimonials.next(testimonials);
        });
    }
    getTestimonials() {
        return this.testiCollection.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((res) => {
            return res.map((e) => {
                return Object.assign(Object.assign({}, e.payload.doc.data()), { tid: e.payload.doc.id });
            });
        }));
    }
    toggleTestimonial(tid, approved) {
        const testiRef = this.firestore.doc(`testimonial/${tid}`);
        testiRef.update({ approved });
    }
    addTestimonial(testimonial) {
        return this.testiCollection.add(testimonial);
    }
    deleteTestimonial(TID) {
        return this.testiCollection.doc(TID).delete();
    }
}
TestimonialsService.ɵfac = function TestimonialsService_Factory(t) { return new (t || TestimonialsService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_3__["AngularFirestore"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_users_service__WEBPACK_IMPORTED_MODULE_4__["UsersService"])); };
TestimonialsService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: TestimonialsService, factory: TestimonialsService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "ZAI4":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser/animations */ "R1ws");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/service-worker */ "Jho9");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../environments/environment */ "AytR");
/* harmony import */ var _angular_fire__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/fire */ "spgP");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/fire/auth */ "UbJi");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");
/* harmony import */ var ng2_adsense__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ng2-adsense */ "Cvm2");
/* harmony import */ var _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @sweetalert2/ngx-sweetalert2 */ "QJFE");
/* harmony import */ var _core_core_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./core/core.module */ "pKmL");
/* harmony import */ var _app_routing__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./app.routing */ "beVS");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./app.component */ "Sy1n");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ "fXoL");


















class AppModule {
}
AppModule.ɵfac = function AppModule_Factory(t) { return new (t || AppModule)(); };
AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_12__["AppComponent"]] });
AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineInjector"]({ providers: [], imports: [[
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
            ng2_adsense__WEBPACK_IMPORTED_MODULE_8__["AdsenseModule"].forRoot({
                adClient: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].addClient,
                adSlot: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].adSlot,
            }),
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_1__["BrowserAnimationsModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClientModule"],
            _core_core_module__WEBPACK_IMPORTED_MODULE_10__["CoreModule"],
            _app_routing__WEBPACK_IMPORTED_MODULE_11__["AppRoutingModule"],
            _angular_fire__WEBPACK_IMPORTED_MODULE_5__["AngularFireModule"].initializeApp(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].firebase),
            _angular_fire_auth__WEBPACK_IMPORTED_MODULE_6__["AngularFireAuthModule"],
            _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_7__["AngularFirestoreModule"],
            _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_9__["SweetAlert2Module"].forRoot(),
            _angular_service_worker__WEBPACK_IMPORTED_MODULE_3__["ServiceWorkerModule"].register('ngsw-worker.js', {
                enabled: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production,
            }),
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_12__["AppComponent"]], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], ng2_adsense__WEBPACK_IMPORTED_MODULE_8__["AdsenseModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_1__["BrowserAnimationsModule"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClientModule"],
        _core_core_module__WEBPACK_IMPORTED_MODULE_10__["CoreModule"],
        _app_routing__WEBPACK_IMPORTED_MODULE_11__["AppRoutingModule"], _angular_fire__WEBPACK_IMPORTED_MODULE_5__["AngularFireModule"], _angular_fire_auth__WEBPACK_IMPORTED_MODULE_6__["AngularFireAuthModule"],
        _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_7__["AngularFirestoreModule"], _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_9__["SweetAlert2Module"], _angular_service_worker__WEBPACK_IMPORTED_MODULE_3__["ServiceWorkerModule"]] }); })();


/***/ }),

/***/ "Zewy":
/*!****************************************************************!*\
  !*** ./src/app/core/modals/conversation/conversation.modal.ts ***!
  \****************************************************************/
/*! exports provided: ConversationModal */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConversationModal", function() { return ConversationModal; });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/toast/Toast.model */ "Lby2");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var src_app_services_forms_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/forms.service */ "G9Ti");
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/toast.service */ "2g2N");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "ofXK");








function ConversationModal_span_58_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Tell me");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function ConversationModal_span_59_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Flying...");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
class ConversationModal {
    constructor(fb, authService, formsService, toastService) {
        this.fb = fb;
        this.authService = authService;
        this.formsService = formsService;
        this.toastService = toastService;
        this.user = null;
        this.conversationForm = this.fb.group({
            name: [
                '',
                [_angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].maxLength(50)],
            ],
            email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].email]],
            phone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].minLength(11)]],
            project: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].required]],
            details: [
                '',
                [
                    _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].minLength(3),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_0__["Validators"].maxLength(1000),
                ],
            ],
        });
        this.isSending = false;
    }
    get name() {
        return this.conversationForm.get('name');
    }
    get email() {
        return this.conversationForm.get('email');
    }
    get phone() {
        return this.conversationForm.get('phone');
    }
    get project() {
        return this.conversationForm.get('project');
    }
    get details() {
        return this.conversationForm.get('details');
    }
    ngOnInit() {
        this.userSubs();
    }
    userSubs() {
        this.authService.user$.subscribe((user) => {
            this.user = user;
            if (user) {
                this.conversationForm.patchValue({
                    name: user.displayName,
                    email: user.email,
                });
            }
            else
                this.conversationForm.reset({});
        });
    }
    onSendForm() {
        if (this.conversationForm.invalid)
            return;
        this.isSending = true;
        this.conversationForm.disable();
        let conversationForm = {
            name: this.name.value,
            email: this.email.value,
            phone: this.phone.value,
            project: this.project.value,
            details: this.details.value,
        };
        if (this.user) {
            conversationForm.uid = this.user.uid;
            conversationForm.name = this.user.displayName;
            conversationForm.email = this.user.email;
        }
        this.formsService.sendConversationForm(conversationForm).then((res) => {
            let toast = new src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__["Toast"]('message sent successfully', 'Thank You, I just recieved your message', 2);
            this.toastService.addToast(toast);
            this.isSending = false;
            this.resetForm();
            this.conversationForm.enable();
        }, (err) => {
            let toast = new src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__["Toast"]('Error', 'There is an error in sending your message', 2);
            this.toastService.addToast(toast);
            this.isSending = false;
            this.conversationForm.enable();
        });
    }
    resetForm() {
        if (!this.user)
            this.conversationForm.reset();
        else
            this.conversationForm.reset({
                name: this.name.value,
                email: this.email.value,
            });
    }
}
ConversationModal.ɵfac = function ConversationModal_Factory(t) { return new (t || ConversationModal)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_forms_service__WEBPACK_IMPORTED_MODULE_4__["FormsService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"])); };
ConversationModal.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: ConversationModal, selectors: [["modal-conversation"]], decls: 61, vars: 30, consts: [["id", "conversationModal", "tabindex", "-1", "aria-labelledby", "conversationModalLabel", "aria-hidden", "true", 1, "modal", "fade"], [1, "modal-dialog", "modal-fullscreen"], [1, "modal-content"], [1, "modal-body"], [1, "d-flex", "justify-content-between", "border-0"], ["src", "assets/imgs/logo/omar-logo.png", "alt", "omar logo", "width", "80px"], [1, "text-center"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn", "icon-cancel"], ["id", "conversationForm", 1, "row", "say-hello-form", 3, "formGroup", "ngSubmit"], [1, "col-12"], [1, "form-floating", "mb-4"], ["id", "name", "type", "text", "formControlName", "name", "placeholder", "Name", 1, "form-control", 3, "readOnly"], ["for", "name"], [1, "invalid-feedback"], ["id", "email", "type", "email", "formControlName", "email", "placeholder", "name@example.com", 1, "form-control", 3, "readOnly"], ["for", "email"], ["id", "phone", "type", "tel", "formControlName", "phone", "placeholder", "+02 1557032911", "placeholder", "Mobile number", 1, "form-control"], ["for", "phone"], ["id", "project", "formControlName", "project", 1, "form-select"], ["value", "website-for-your-company"], ["value", "ecommerce-Website"], ["value", "angular/ionic-app"], ["value", "nodejs-server"], ["for", "project"], ["id", "details", "formControlName", "details", "placeholder", "Additional Details", 1, "form-control", "form-control-lg", 2, "min-height", "150px"], ["for", "details", 1, "form-label"], [1, "modal-footer", "border-0", "justify-content-center"], ["type", "submit", "form", "conversationForm", 1, "btn", "btn-secondary", "rounded-pill", "btn-lg", "px-5", "d-flex", "align-items-center", 3, "disabled"], [4, "ngIf"], [1, "reset-icon", "ms-2"]], template: function ConversationModal_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "img", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "h2", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](8, " Want to discuss a startup collaboration? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](9, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10, " I'm most definitely game. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](11, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "form", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngSubmit", function ConversationModal_Template_form_ngSubmit_12_listener() { return ctx.onSendForm(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](15, "input", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](16, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](17, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](18, "Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](20, "What's your name?");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](21, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](23, "input", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](24, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](25, "label", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](26, "Email address");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](27, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](28, "Tell me your email so that I can reply to you");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](29, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](30, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](31, "input", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](32, "label", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](33, "Mobile Number");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](34, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](35, "give me a real number plz.");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](36, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](37, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](38, "select", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](39, "option", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](40, "Website for your company");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](41, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](42, "Ecommerce Website");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](43, "option", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](44, "Angular/Ionic App");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](45, "option", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](46, "Nodejs Server");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](47, "label", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](48, "Type of project");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](49, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](50, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](51, "textarea", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](52, "label", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](53, "Additional Details");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](54, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](55, "I will try my best to help you with whatever you want");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](56, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](57, "button", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](58, ConversationModal_span_58_Template, 2, 0, "span", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](59, ConversationModal_span_59_Template, 2, 0, "span", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](60, "i", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx.conversationForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("is-invalid", ctx.name.invalid && ctx.name.touched)("is-valid", ctx.name.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("readOnly", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](16, 26, ctx.authService.user$));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("is-invalid", ctx.email.invalid && ctx.email.touched)("is-valid", ctx.email.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("readOnly", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](24, 28, ctx.authService.user$));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("is-invalid", ctx.phone.invalid && ctx.phone.touched)("is-valid", ctx.phone.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("is-invalid", ctx.details.invalid && ctx.details.touched)("is-valid", ctx.details.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx.conversationForm.invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.isSending);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.isSending);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("icon-send", !ctx.isSending)("icon-sending", ctx.isSending);
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_0__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormGroupDirective"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormControlName"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["SelectControlValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["NgSelectOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["ɵangular_packages_forms_forms_x"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgIf"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["AsyncPipe"]], styles: [".say-hello-form[_ngcontent-%COMP%] {\n  max-width: 500px;\n  margin: auto;\n  padding: 30px 15px 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2NvbnZlcnNhdGlvbi5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7QUFDRiIsImZpbGUiOiJjb252ZXJzYXRpb24ubW9kYWwuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zYXktaGVsbG8tZm9ybSB7XG4gIG1heC13aWR0aDogNTAwcHg7XG4gIG1hcmdpbjogYXV0bztcbiAgcGFkZGluZzogMzBweCAxNXB4IDE1cHg7XG59XG4iXX0= */"] });


/***/ }),

/***/ "ZtWP":
/*!*********************************************!*\
  !*** ./src/app/services/company.service.ts ***!
  \*********************************************/
/*! exports provided: CompanyService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompanyService", function() { return CompanyService; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");



class CompanyService {
    constructor(firestore) {
        this.firestore = firestore;
        this.companies = new rxjs__WEBPACK_IMPORTED_MODULE_0__["BehaviorSubject"]([]);
        this.companyCollection = this.firestore.collection('company');
    }
    getCompanies() {
        return this.companyCollection.snapshotChanges();
    }
    addCompany(company) {
        return this.companyCollection.add(company);
    }
    deleteCompany(CID) {
        return this.companyCollection.doc(CID).delete();
    }
}
CompanyService.ɵfac = function CompanyService_Factory(t) { return new (t || CompanyService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"])); };
CompanyService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: CompanyService, factory: CompanyService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "bT90":
/*!**************************************************************************!*\
  !*** ./src/app/shared/components/user-account/user-account.component.ts ***!
  \**************************************************************************/
/*! exports provided: UserAccountComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserAccountComponent", function() { return UserAccountComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");



function UserAccountComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "img", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "h3", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "p", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const user_r3 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", user_r3.photoURL, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"])("alt", user_r3.displayName)("title", user_r3.displayName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](user_r3.displayName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](user_r3.email);
} }
function UserAccountComponent_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UserAccountComponent_ng_template_2_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r4.onLogin(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, " login with google");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
class UserAccountComponent {
    constructor(authService) {
        this.authService = authService;
    }
    ngOnInit() { }
    onLogin() {
        this.authService.showOneTapGoogle();
    }
}
UserAccountComponent.ɵfac = function UserAccountComponent_Factory(t) { return new (t || UserAccountComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"])); };
UserAccountComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: UserAccountComponent, selectors: [["app-user-account"]], decls: 4, vars: 4, consts: [[4, "ngIf", "ngIfElse"], ["guest", ""], [1, "user-profile"], [1, "user-image"], [1, "img-fluid", 3, "src", "alt", "title"], [1, "m-0"], [1, "btn", "btn-primary", "login-google", 3, "click"], [1, "icon-google-plus"]], template: function UserAccountComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, UserAccountComponent_ng_container_0_Template, 9, 5, "ng-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](1, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, UserAccountComponent_ng_template_2_Template, 3, 0, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    } if (rf & 2) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](1, 2, ctx.authService.user$))("ngIfElse", _r1);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["AsyncPipe"]], styles: [".user-profile[_ngcontent-%COMP%] {\n  padding: 10px;\n  text-align: center;\n}\n.user-profile[_ngcontent-%COMP%]   .user-image[_ngcontent-%COMP%] {\n  max-width: 200px;\n  max-height: 200px;\n  border-radius: 50%;\n  overflow: hidden;\n  margin: auto;\n  display: inline-block;\n}\n.user-profile[_ngcontent-%COMP%]   .login-google[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  margin-bottom: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3VzZXItYWNjb3VudC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxrQkFBQTtBQUNGO0FBQ0U7RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtBQUNKO0FBQ0U7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQUNKIiwiZmlsZSI6InVzZXItYWNjb3VudC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi51c2VyLXByb2ZpbGUge1xuICBwYWRkaW5nOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cbiAgLnVzZXItaW1hZ2Uge1xuICAgIG1heC13aWR0aDogMjAwcHg7XG4gICAgbWF4LWhlaWdodDogMjAwcHg7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgbWFyZ2luOiBhdXRvO1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgfVxuICAubG9naW4tZ29vZ2xlIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgfVxufVxuIl19 */"] });


/***/ }),

/***/ "beVS":
/*!********************************!*\
  !*** ./src/app/app.routing.ts ***!
  \********************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _auth_admin_guard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth/admin.guard */ "BZQQ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-home-home-module */ "pages-home-home-module").then(__webpack_require__.bind(null, /*! ./pages/home/home.module */ "99Un")).then((m) => m.HomePageModule),
        pathMatch: 'full',
    },
    {
        path: 'dashboard',
        canLoad: [_auth_admin_guard__WEBPACK_IMPORTED_MODULE_1__["AdminGuard"]],
        canActivate: [_auth_admin_guard__WEBPACK_IMPORTED_MODULE_1__["AdminGuard"]],
        canActivateChild: [_auth_admin_guard__WEBPACK_IMPORTED_MODULE_1__["AdminGuard"]],
        loadChildren: () => __webpack_require__.e(/*! import() | pages-dashboard-dashboard-module */ "pages-dashboard-dashboard-module").then(__webpack_require__.bind(null, /*! ./pages/dashboard/dashboard.module */ "/2RN")).then((m) => m.DashboardPageModule),
    },
    {
        path: 'about',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-about-about-module */ "pages-about-about-module").then(__webpack_require__.bind(null, /*! ./pages/about/about.module */ "UoYK")).then((m) => m.AboutPageModule),
    },
    {
        path: 'services',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-services-services-module */ "pages-services-services-module").then(__webpack_require__.bind(null, /*! ./pages/services/services.module */ "XaN2")).then((m) => m.ServicesPageModule),
    },
    {
        path: 'portfolio',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-portfolio-portfolio-module */ "pages-portfolio-portfolio-module").then(__webpack_require__.bind(null, /*! ./pages/portfolio/portfolio.module */ "0rid")).then((m) => m.PortfolioPageModule),
    },
    {
        path: 'companies',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-companies-companies-module */ "pages-companies-companies-module").then(__webpack_require__.bind(null, /*! ./pages/companies/companies.module */ "xMYf")).then((m) => m.CompaniesPageModule),
    },
    {
        path: 'testimonials',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-testimonials-testimonials-module */ "pages-testimonials-testimonials-module").then(__webpack_require__.bind(null, /*! ./pages/testimonials/testimonials.module */ "jiYq")).then((m) => m.TestimonialsPageModule),
    },
    {
        path: 'contact-me',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-contact-contact-module */ "pages-contact-contact-module").then(__webpack_require__.bind(null, /*! ./pages/contact/contact.module */ "14/Y")).then((m) => m.ContactPageModule),
    },
    {
        path: 'privacy-policy',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-privacy-policy-privacy-policy-module */ "pages-privacy-policy-privacy-policy-module").then(__webpack_require__.bind(null, /*! ./pages/privacy-policy/privacy-policy.module */ "cjqQ")).then((m) => m.PrivacyPolicyPageModule),
    },
    { path: '**', redirectTo: '' },
];
class AppRoutingModule {
}
AppRoutingModule.ɵfac = function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); };
AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forRoot(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "gBp8":
/*!****************************************************************!*\
  !*** ./src/app/shared/components/company/company.component.ts ***!
  \****************************************************************/
/*! exports provided: CompanyComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompanyComponent", function() { return CompanyComponent; });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ "AytR");
/* harmony import */ var src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/toast/Toast.model */ "Lby2");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_services_company_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/company.service */ "ZtWP");
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/toast.service */ "2g2N");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @sweetalert2/ngx-sweetalert2 */ "QJFE");








function CompanyComponent_ng_container_5_i_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "i", 9);
} }
function CompanyComponent_ng_container_5_i_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "i", 10);
} }
const _c0 = function (a1) { return { title: "Are you sure?", html: a1, confirmButtonText: "Delete", confirmButtonColor: "var(--bs-danger)", showCancelButton: true }; };
function CompanyComponent_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "button", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("confirm", function CompanyComponent_ng_container_5_Template_button_confirm_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r4); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r3.deleteCompany(ctx_r3.company.cid || ""); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, CompanyComponent_ng_container_5_i_2_Template, 1, 0, "i", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, CompanyComponent_ng_container_5_i_3_Template, 1, 0, "i", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx_r0.isDeleting === ctx_r0.company.cid)("swal", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](4, _c0, "Do you want to delete <strong class='text-danger'>" + ctx_r0.company.name + "</strong>?"));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx_r0.isDeleting === ctx_r0.company.cid);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx_r0.isDeleting !== ctx_r0.company.cid);
} }
class CompanyComponent {
    constructor(companyService, toastService, authService) {
        this.companyService = companyService;
        this.toastService = toastService;
        this.authService = authService;
        this.company = { imageURL: '', link: '', name: '', cid: '' };
        this.adminID = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__["environment"].adminID;
    }
    ngOnInit() { }
    deleteCompany(CID) {
        if (this.isDeleting)
            return;
        this.isDeleting = CID;
        this.companyService
            .deleteCompany(CID)
            .then((res) => {
            this.isDeleting = undefined;
            let toast = new src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__["Toast"]('company deleted', 'Company deleted successfully', 2);
            this.toastService.addToast(toast);
        })
            .catch((err) => {
            let toast = new src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_1__["Toast"]('error in deleting', 'error in deleting company', 2);
            this.toastService.addToast(toast);
            this.isDeleting = undefined;
        });
    }
}
CompanyComponent.ɵfac = function CompanyComponent_Factory(t) { return new (t || CompanyComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_company_service__WEBPACK_IMPORTED_MODULE_3__["CompanyService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_4__["ToastService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"])); };
CompanyComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: CompanyComponent, selectors: [["app-company"]], inputs: { company: "company" }, decls: 7, vars: 6, consts: [[1, "company", "card"], [1, "inner"], [1, "img-fluid", 3, "src", "alt"], ["target", "_blank", 1, "company-link", 3, "href"], [1, "icon-link"], [4, "ngIf"], [1, "delete-btn", "btn-sm", "btn", "text-danger", 3, "disabled", "swal", "confirm"], ["class", "icon-reload reset-icon rotating", 4, "ngIf"], ["class", "icon-cancel reset-icon", 4, "ngIf"], [1, "icon-reload", "reset-icon", "rotating"], [1, "icon-cancel", "reset-icon"]], template: function CompanyComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "img", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "a", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](4, "i", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](5, CompanyComponent_ng_container_5_Template, 4, 6, "ng-container", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](6, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        let tmp_3_0 = null;
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("src", "assets/imgs/companies/" + ctx.company.imageURL, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"])("alt", ctx.company.name);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("href", ctx.company.link, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ((tmp_3_0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](6, 4, ctx.authService.user$)) == null ? null : tmp_3_0.uid) === ctx.adminID);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["NgIf"], _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_7__["SwalDirective"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["AsyncPipe"]], styles: [".company[_ngcontent-%COMP%] {\n  text-align: center;\n  padding: 15px;\n  position: relative;\n  overflow: hidden;\n  box-shadow: var(--nav-shadow);\n  border-radius: 12px;\n  border: 0;\n  max-width: 350px;\n  margin: auto;\n  margin-bottom: 20px;\n}\n.company[_ngcontent-%COMP%]   .company-link[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  z-index: 20;\n  opacity: 0;\n  transition: opacity 200ms ease-in-out;\n  background-color: #fff;\n}\n.company[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  max-width: 210px;\n  margin: auto;\n}\n.company[_ngcontent-%COMP%]:hover   .company-link[_ngcontent-%COMP%] {\n  opacity: 0.95;\n}\n.company[_ngcontent-%COMP%]   .delete-btn[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 5px;\n  right: 5px;\n  z-index: 100;\n  border-radius: 50%;\n  width: 25px;\n  padding: unset;\n  height: 25px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.company[_ngcontent-%COMP%]   .delete-btn[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  font-size: 15px;\n}\n.company[_ngcontent-%COMP%]   .delete-btn[_ngcontent-%COMP%]:hover {\n  background-color: var(--bs-danger);\n}\n.company[_ngcontent-%COMP%]   .delete-btn[_ngcontent-%COMP%]:hover   i[_ngcontent-%COMP%] {\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2NvbXBhbnkuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsNkJBQUE7RUFDQSxtQkFBQTtFQUNBLFNBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQUNGO0FBQUU7RUFDRSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EscUNBQUE7RUFDQSxzQkFBQTtBQUVKO0FBQUU7RUFDRSxnQkFBQTtFQUNBLFlBQUE7QUFFSjtBQUNJO0VBQ0UsYUFBQTtBQUNOO0FBRUU7RUFDRSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFBSjtBQUNJO0VBQ0UsZUFBQTtBQUNOO0FBQ0k7RUFDRSxrQ0FBQTtBQUNOO0FBQU07RUFDRSxXQUFBO0FBRVIiLCJmaWxlIjoiY29tcGFueS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb21wYW55IHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiAxNXB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGJveC1zaGFkb3c6IHZhcigtLW5hdi1zaGFkb3cpO1xuICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICBib3JkZXI6IDA7XG4gIG1heC13aWR0aDogMzUwcHg7XG4gIG1hcmdpbjogYXV0bztcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgLmNvbXBhbnktbGluayB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMDtcbiAgICBsZWZ0OiAwO1xuICAgIHJpZ2h0OiAwO1xuICAgIGJvdHRvbTogMDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgei1pbmRleDogMjA7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2l0aW9uOiBvcGFjaXR5IDIwMG1zIGVhc2UtaW4tb3V0O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIH1cbiAgaW1nIHtcbiAgICBtYXgtd2lkdGg6IDIxMHB4O1xuICAgIG1hcmdpbjogYXV0bztcbiAgfVxuICAmOmhvdmVyIHtcbiAgICAuY29tcGFueS1saW5rIHtcbiAgICAgIG9wYWNpdHk6IDAuOTU7XG4gICAgfVxuICB9XG4gIC5kZWxldGUtYnRuIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiA1cHg7XG4gICAgcmlnaHQ6IDVweDtcbiAgICB6LWluZGV4OiAxMDA7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIHdpZHRoOiAyNXB4O1xuICAgIHBhZGRpbmc6IHVuc2V0O1xuICAgIGhlaWdodDogMjVweDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgaSB7XG4gICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgfVxuICAgICY6aG92ZXIge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYnMtZGFuZ2VyKTtcbiAgICAgIGkge1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdfQ== */"] });


/***/ }),

/***/ "pKmL":
/*!*************************************!*\
  !*** ./src/app/core/core.module.ts ***!
  \*************************************/
/*! exports provided: CoreModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoreModule", function() { return CoreModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _toast_toast_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./toast/toast.component */ "2hTU");
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./footer/footer.component */ "FxTl");
/* harmony import */ var _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./navbar/navbar.component */ "R2Se");
/* harmony import */ var _sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sidebar/sidebar.component */ "1qzX");
/* harmony import */ var _splash_screen_splash_screen_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./splash-screen/splash-screen.component */ "yuSF");
/* harmony import */ var _modals_say_hello_say_hello_modal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./modals/say-hello/say-hello.modal */ "EvY5");
/* harmony import */ var _modals_conversation_conversation_modal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./modals/conversation/conversation.modal */ "Zewy");
/* harmony import */ var _modals_add_testimonial_add_testimonial_modal__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./modals/add-testimonial/add-testimonial.modal */ "Na6d");
/* harmony import */ var _modals_join_team_join_team_modal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./modals/join-team/join-team.modal */ "7fBr");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../shared/shared.module */ "PCNd");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ "fXoL");



// Components





// Modals




//Modules


const CoreModules = [
    _footer_footer_component__WEBPACK_IMPORTED_MODULE_4__["FooterComponent"],
    _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_5__["NavbarComponent"],
    _sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_6__["SidebarComponent"],
    _toast_toast_component__WEBPACK_IMPORTED_MODULE_3__["ToastComponent"],
    _modals_say_hello_say_hello_modal__WEBPACK_IMPORTED_MODULE_8__["SayHelloModal"],
    _modals_conversation_conversation_modal__WEBPACK_IMPORTED_MODULE_9__["ConversationModal"],
    _modals_add_testimonial_add_testimonial_modal__WEBPACK_IMPORTED_MODULE_10__["AddTestimonialModal"],
    _splash_screen_splash_screen_component__WEBPACK_IMPORTED_MODULE_7__["SplashScreenComponent"],
    _modals_join_team_join_team_modal__WEBPACK_IMPORTED_MODULE_11__["JoinTeamComponent"],
];
class CoreModule {
}
CoreModule.ɵfac = function CoreModule_Factory(t) { return new (t || CoreModule)(); };
CoreModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineNgModule"]({ type: CoreModule });
CoreModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"], _shared_shared_module__WEBPACK_IMPORTED_MODULE_12__["SharedModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsetNgModuleScope"](CoreModule, { declarations: [_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__["FooterComponent"],
        _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_5__["NavbarComponent"],
        _sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_6__["SidebarComponent"],
        _toast_toast_component__WEBPACK_IMPORTED_MODULE_3__["ToastComponent"],
        _modals_say_hello_say_hello_modal__WEBPACK_IMPORTED_MODULE_8__["SayHelloModal"],
        _modals_conversation_conversation_modal__WEBPACK_IMPORTED_MODULE_9__["ConversationModal"],
        _modals_add_testimonial_add_testimonial_modal__WEBPACK_IMPORTED_MODULE_10__["AddTestimonialModal"],
        _splash_screen_splash_screen_component__WEBPACK_IMPORTED_MODULE_7__["SplashScreenComponent"],
        _modals_join_team_join_team_modal__WEBPACK_IMPORTED_MODULE_11__["JoinTeamComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"], _shared_shared_module__WEBPACK_IMPORTED_MODULE_12__["SharedModule"]], exports: [_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__["FooterComponent"],
        _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_5__["NavbarComponent"],
        _sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_6__["SidebarComponent"],
        _toast_toast_component__WEBPACK_IMPORTED_MODULE_3__["ToastComponent"],
        _modals_say_hello_say_hello_modal__WEBPACK_IMPORTED_MODULE_8__["SayHelloModal"],
        _modals_conversation_conversation_modal__WEBPACK_IMPORTED_MODULE_9__["ConversationModal"],
        _modals_add_testimonial_add_testimonial_modal__WEBPACK_IMPORTED_MODULE_10__["AddTestimonialModal"],
        _splash_screen_splash_screen_component__WEBPACK_IMPORTED_MODULE_7__["SplashScreenComponent"],
        _modals_join_team_join_team_modal__WEBPACK_IMPORTED_MODULE_11__["JoinTeamComponent"]] }); })();


/***/ }),

/***/ "pPLs":
/*!**********************************************************!*\
  !*** ./src/app/shared/components/team/team.component.ts ***!
  \**********************************************************/
/*! exports provided: TeamComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamComponent", function() { return TeamComponent; });
/* harmony import */ var src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/toast/Toast.model */ "Lby2");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ "AytR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_services_team_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/team.service */ "GDbA");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/toast.service */ "2g2N");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @sweetalert2/ngx-sweetalert2 */ "QJFE");








function TeamComponent_ng_container_1_div_1_ng_container_2_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "button", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function TeamComponent_ng_container_1_div_1_ng_container_2_ng_container_1_Template_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r9); const person_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](3).$implicit; const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r7.togglePerson(person_r1.tid || "", true); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "span", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} }
function TeamComponent_ng_container_1_div_1_ng_container_2_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "button", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function TeamComponent_ng_container_1_div_1_ng_container_2_ng_container_2_Template_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r12); const person_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](3).$implicit; const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r10.togglePerson(person_r1.tid || "", false); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} }
const _c0 = function (a1) { return { title: "Are you sure?", html: a1, confirmButtonText: "Delete", confirmButtonColor: "var(--bs-danger)", showCancelButton: true }; };
function TeamComponent_ng_container_1_div_1_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, TeamComponent_ng_container_1_div_1_ng_container_2_ng_container_1_Template, 3, 0, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, TeamComponent_ng_container_1_div_1_ng_container_2_ng_container_2_Template, 3, 0, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("confirm", function TeamComponent_ng_container_1_div_1_ng_container_2_Template_button_confirm_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r15); const person_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](2).$implicit; const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r13.deletePerson(person_r1.tid || ""); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](4, "span", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const person_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](2).$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !person_r1.approved);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", person_r1.approved);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx_r3.isDeleting === person_r1.tid)("swal", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](4, _c0, "Do you want to delete <strong class='text-danger'>" + person_r1.user.displayName + "</strong>?"));
} }
function TeamComponent_ng_container_1_div_1_ng_container_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "span", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2, "Waiting for approve");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} }
function TeamComponent_ng_container_1_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, TeamComponent_ng_container_1_div_1_ng_container_2_Template, 5, 6, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "img", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](8, TeamComponent_ng_container_1_div_1_ng_container_8_Template, 3, 0, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "h3", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "strong", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "p", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](15, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "a", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](17, "span", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "a", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](19, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "a", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](21, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "a", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](23, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const person_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    let tmp_0_0 = null;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ((tmp_0_0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](3, 11, ctx_r2.authService.user$)) == null ? null : tmp_0_0.uid) === ctx_r2.adminID);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("src", person_r1.user.photoURL, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"])("alt", person_r1.user.displayName);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !person_r1.approved);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](person_r1.user.displayName);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](person_r1.position);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](person_r1.description);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("href", person_r1.social.facebook, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("href", person_r1.social.twitter, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("href", person_r1.social.instagram, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("href", person_r1.social.linkedin, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"]);
} }
function TeamComponent_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, TeamComponent_ng_container_1_div_1_Template, 24, 13, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const person_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", person_r1.user);
} }
class TeamComponent {
    constructor(teamService, authService, toastService) {
        this.teamService = teamService;
        this.authService = authService;
        this.toastService = toastService;
        this.team = [];
        this.adminID = src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].adminID;
    }
    ngOnInit() { }
    togglePerson(tid, isApproved) {
        this.teamService.togglePerson(tid, isApproved);
    }
    deletePerson(tid) {
        if (this.isDeleting)
            return;
        this.isDeleting = tid;
        this.teamService
            .deletePerson(tid)
            .then((res) => {
            this.isDeleting = undefined;
            let toast = new src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_0__["Toast"]('person deleted', 'Person deleted successfully', 2);
            this.toastService.addToast(toast);
        })
            .catch((err) => {
            let toast = new src_app_core_toast_Toast_model__WEBPACK_IMPORTED_MODULE_0__["Toast"]('error in deleting', 'error in deleting person', 2);
            this.toastService.addToast(toast);
            this.isDeleting = undefined;
        });
    }
}
TeamComponent.ɵfac = function TeamComponent_Factory(t) { return new (t || TeamComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_team_service__WEBPACK_IMPORTED_MODULE_3__["TeamService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"])); };
TeamComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: TeamComponent, selectors: [["app-team"]], inputs: { team: "team" }, decls: 2, vars: 1, consts: [[1, "row", "g-3"], [4, "ngFor", "ngForOf"], ["class", "col-md-6 col-lg-4 col-xl-4", 4, "ngIf"], [1, "col-md-6", "col-lg-4", "col-xl-4"], [1, "person", "card", "shadow"], [4, "ngIf"], [1, "person-img"], [1, "img-border"], [3, "src", "alt"], [1, "card-body"], [1, "mb-0", "person-title"], [1, "person-sub-title"], [1, "mb-4", "mt-3"], [1, "card-footer"], ["target", "_blank", 3, "href"], [1, "icon-facebook", "reset-icon", "text-white"], [1, "icon-twitter", "reset-icon", "text-white"], [1, "icon-instagram", "reset-icon", "text-white"], [1, "icon-linkedin", "reset-icon", "text-white"], [1, "btn", "btn-danger", "btn-sm", 3, "disabled", "swal", "confirm"], [1, "icon-delete", "reset-icon"], [1, "btn", "btn-primary", "btn-sm", 3, "click"], [1, "icon-check-mark", "reset-icon"], [1, "btn", "btn-warning", "btn-sm", 3, "click"], [1, "icon-cancel", "reset-icon"], [1, "testimonial-badge", "badge", "bg-warning", "text-dark", "rounded-pill", "mb-2"]], template: function TeamComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, TeamComponent_ng_container_1_Template, 2, 1, "ng-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.team);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgIf"], _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_7__["SwalDirective"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["AsyncPipe"]], styles: [".person[_ngcontent-%COMP%] {\n  border: 0;\n  margin: auto;\n  margin-top: 70px;\n  border-radius: 50px 50px 30px 30px;\n  max-width: 300px;\n  position: relative;\n  padding-top: 50px;\n  background-color: var(--nav-bg);\n  text-align: center;\n}\n.person-img[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -50px;\n  left: 50%;\n  transform: translate(-50%, 0);\n  border-radius: 50%;\n  padding: 5px;\n  background-color: var(--light);\n  width: 100px;\n  margin: auto;\n}\n.person-img[_ngcontent-%COMP%]   .img-border[_ngcontent-%COMP%] {\n  border-radius: 50%;\n  padding: 5px;\n  background-color: var(--dark);\n}\n.person-img[_ngcontent-%COMP%]   .img-border[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  border-radius: 50%;\n}\n.person[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%] {\n  padding: 10px 30px;\n  min-height: 280px;\n}\n.person[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  text-align: justify;\n}\n.person[_ngcontent-%COMP%]   .card-footer[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-evenly;\n  border-radius: 0px 0px 20px 20px;\n  padding: 20px 0;\n  background-color: var(--bs-primary);\n}\n.person-img[_ngcontent-%COMP%] {\n  max-width: 200px;\n  max-height: 200px;\n  border-radius: 50%;\n  display: inline-block;\n  overflow: hidden;\n}\n.btn[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 10px;\n  left: 20%;\n  padding: 5px;\n  padding-bottom: 2px;\n}\n.btn[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 15px;\n}\n.btn.btn-danger[_ngcontent-%COMP%] {\n  left: 70%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3RlYW0uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxTQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSwrQkFBQTtFQUNBLGtCQUFBO0FBQ0Y7QUFBRTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7RUFDQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLDhCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFFSjtBQURJO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7QUFHTjtBQUZNO0VBQ0Usa0JBQUE7QUFJUjtBQUFFO0VBQ0Usa0JBQUE7RUFDQSxpQkFBQTtBQUVKO0FBQUk7RUFDRSxtQkFBQTtBQUVOO0FBRUU7RUFDRSxhQUFBO0VBQ0EsNkJBQUE7RUFDQSxnQ0FBQTtFQUNBLGVBQUE7RUFDQSxtQ0FBQTtBQUFKO0FBSUE7RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGdCQUFBO0FBREY7QUFJQTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFNBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUFERjtBQUVFO0VBQ0UsZUFBQTtBQUFKO0FBR0U7RUFDRSxTQUFBO0FBREoiLCJmaWxlIjoidGVhbS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wZXJzb24ge1xuICBib3JkZXI6IDA7XG4gIG1hcmdpbjogYXV0bztcbiAgbWFyZ2luLXRvcDogNzBweDtcbiAgYm9yZGVyLXJhZGl1czogNTBweCA1MHB4IDMwcHggMzBweDtcbiAgbWF4LXdpZHRoOiAzMDBweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBwYWRkaW5nLXRvcDogNTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbmF2LWJnKTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAmLWltZyB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogLTUwcHg7XG4gICAgbGVmdDogNTAlO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIDApO1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICBwYWRkaW5nOiA1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbGlnaHQpO1xuICAgIHdpZHRoOiAxMDBweDtcbiAgICBtYXJnaW46IGF1dG87XG4gICAgLmltZy1ib3JkZXIge1xuICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgcGFkZGluZzogNXB4O1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tZGFyayk7XG4gICAgICBpbWcge1xuICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIC5jYXJkLWJvZHkge1xuICAgIHBhZGRpbmc6IDEwcHggMzBweDtcbiAgICBtaW4taGVpZ2h0OiAyODBweDtcblxuICAgIHAge1xuICAgICAgdGV4dC1hbGlnbjoganVzdGlmeTtcbiAgICB9XG4gIH1cblxuICAuY2FyZC1mb290ZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1ldmVubHk7XG4gICAgYm9yZGVyLXJhZGl1czogMHB4IDBweCAyMHB4IDIwcHg7XG4gICAgcGFkZGluZzogMjBweCAwO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWJzLXByaW1hcnkpO1xuICB9XG59XG5cbi5wZXJzb24taW1nIHtcbiAgbWF4LXdpZHRoOiAyMDBweDtcbiAgbWF4LWhlaWdodDogMjAwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4uYnRuIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDEwcHg7XG4gIGxlZnQ6IDIwJTtcbiAgcGFkZGluZzogNXB4O1xuICBwYWRkaW5nLWJvdHRvbTogMnB4O1xuICBzcGFuIHtcbiAgICBmb250LXNpemU6IDE1cHg7XG4gIH1cblxuICAmLmJ0bi1kYW5nZXIge1xuICAgIGxlZnQ6IDcwJTtcbiAgfVxufVxuIl19 */"] });


/***/ }),

/***/ "qXBG":
/*!**************************************!*\
  !*** ./src/app/auth/auth.service.ts ***!
  \**************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ "AytR");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! firebase/app */ "Jgta");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/fire/auth */ "UbJi");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");







class AuthService {
    constructor(fireAuth, firestore) {
        this.fireAuth = fireAuth;
        this.firestore = firestore;
        this.user$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](null);
        this.hideOneTapGoogle = false;
        this.initGoogleOneTap();
    }
    initGoogleOneTap() {
        window.onload = () => {
            google.accounts.id.initialize({
                client_id: src_environments_environment__WEBPACK_IMPORTED_MODULE_0__["environment"].clientId,
                cancel_on_tap_outside: true,
                callback: (token) => {
                    this.handleToken(token);
                },
            });
            this.fireAuth.onAuthStateChanged((user) => {
                if (user) {
                    const titlePipe = new _angular_common__WEBPACK_IMPORTED_MODULE_1__["TitleCasePipe"]();
                    const currentUser = {
                        uid: user.uid,
                        displayName: titlePipe.transform(user.displayName),
                        email: user.email,
                        photoURL: user.photoURL,
                        phone: user.phone || null,
                    };
                    this.updateUserData(currentUser);
                }
                else {
                    this.user$.next(null);
                    if (!this.hideOneTapGoogle)
                        google.accounts.id.prompt();
                    this.hideOneTapGoogle = true;
                }
            });
        };
    }
    handleToken(token) {
        const credential = firebase_app__WEBPACK_IMPORTED_MODULE_3__["default"].auth.GoogleAuthProvider.credential(token.credential);
        this.fireAuth.signInWithCredential(credential);
    }
    updateUserData(user) {
        this.user$.next(user);
        const userRef = this.firestore.doc(`users/${user.uid}`);
        userRef.set(user, { merge: true });
    }
    showOneTapGoogle() {
        google.accounts.id.prompt((notification) => {
            if (notification.isNotDisplayed() || notification.isSkippedMoment()) {
                this.fireAuth.signInWithPopup(new firebase_app__WEBPACK_IMPORTED_MODULE_3__["default"].auth.GoogleAuthProvider());
            }
        });
    }
    signOut() {
        this.fireAuth.signOut();
        this.user$.next(null);
    }
}
AuthService.ɵfac = function AuthService_Factory(t) { return new (t || AuthService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_fire_auth__WEBPACK_IMPORTED_MODULE_5__["AngularFireAuth"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_6__["AngularFirestore"])); };
AuthService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({ token: AuthService, factory: AuthService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "whMB":
/*!********************************************************************!*\
  !*** ./src/app/shared/components/tools-svg/tools-svg.component.ts ***!
  \********************************************************************/
/*! exports provided: ToolsSvgComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolsSvgComponent", function() { return ToolsSvgComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");

class ToolsSvgComponent {
    constructor() {
        this.bg = '#ffffff';
    }
    ngOnInit() { }
}
ToolsSvgComponent.ɵfac = function ToolsSvgComponent_Factory(t) { return new (t || ToolsSvgComponent)(); };
ToolsSvgComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ToolsSvgComponent, selectors: [["app-tools-svg"]], inputs: { bg: "bg" }, decls: 87, vars: 29, consts: [["width", "100%", "height", "100%", "viewBox", "0 0 650 265", "version", "1.1", "xmlns", "http://www.w3.org/2000/svg", 0, "xmlns", "xlink", "http://www.w3.org/1999/xlink", 2, "max-width", "750px"], ["id", "Website", "stroke", "none", "stroke-width", "1", "fill", "none", "fill-rule", "evenodd"], ["id", "Group-32", "transform", "translate(0.000000, 3.000000)"], ["d", "M126.007899,38.7650154 C126.007899,34.7383476 129.263975,31.4816286 133.298472,31.4816286 L386.871877,31.4816286 C390.898902,31.4816286 394.162451,34.7405 394.162451,38.7650154 L394.162451,212.307477 C394.162451,216.334145 390.906375,219.590864 386.871877,219.590864 L133.298472,219.590864 C129.271447,219.590864 126.007899,216.331993 126.007899,212.307477 L126.007899,38.7650154 Z", "id", "Case", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["d", "M142.409667,50.7365341 C142.409667,49.0123794 143.813338,47.612711 145.535934,47.612711 L374.37407,47.612711 C376.102828,47.612711 377.500337,49.004393 377.500337,50.7365341 L377.500337,180.042016 C377.500337,181.766171 376.096666,183.165839 374.37407,183.165839 L145.535934,183.165839 C143.807176,183.165839 142.409667,181.774157 142.409667,180.042016 L142.409667,50.7365341 Z", "id", "Case", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["d", "M240.989547,219.590864 L279.441148,219.590864 L282.037136,253.153923 L238.39356,253.153923 L240.989547,219.590864 Z", "id", "Case", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["d", "M222.334407,253.411496 L222.334407,256.926514 C222.334407,259.006825 224.024461,260.699106 226.104395,260.699106 L294.3263,260.699106 C296.402444,260.699106 298.096288,259.006629 298.096288,256.926514 L298.096288,253.411496 C298.096288,253.265769 297.983625,253.153923 297.834738,253.153923 L222.595957,253.153923 C222.450148,253.153923 222.334407,253.269384 222.334407,253.411496 Z", "id", "Keyboard", "stroke", "#39FF14", "stroke-width", "2.08142999", "transform", "translate(260.215348, 256.926514) scale(1, -1) translate(-260.215348, -256.926514) "], ["id", "Oval-6", "stroke", "#39FF14", "stroke-width", "2.08142999", "cx", "260.215348", "cy", "202.809335", "rx", "4.81639213", "ry", "4.81330685"], ["id", "Case", "stroke", "#39FF14", "stroke-width", "2.08142999", "x", "101.275074", "y", "159.749752", "width", "51.5470788", "height", "100.949355", "rx", "6.24428997"], ["d", "M101.275074,170.937438 L152.822153,170.937438 L152.822153,245.686792 L101.275074,245.686792 L101.275074,170.937438 Z", "id", "Case", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "114.812374", "y", "164.17279", "width", "24.7328244", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "124.184813", "y", "250.031778", "width", "5.93587786", "height", "5.93207547", "rx", "2.96603774"], ["id", "Oval-6", "stroke", "#39FF14", "stroke-width", "2.08142999", "cx", "115.853757", "cy", "208.142999", "rx", "3.9051828", "ry", "3.90268123"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "124.96585", "y", "201.378352", "width", "18.2241864", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "124.96585", "y", "207.102284", "width", "13.017276", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "124.96585", "y", "212.826216", "width", "7.81036561", "height", "2.08142999", "rx", "1.040715"], ["id", "Oval-7", "stroke", "#39FF14", "stroke-width", "2.08142999", "cx", "74.8493371", "cy", "168.725919", "rx", "39.9637045", "ry", "39.9374379"], ["id", "Case", "stroke", "#39FF14", "stroke-width", "2.08142999", "x", "319.704966", "y", "120.462761", "width", "192.654351", "height", "129.308838", "rx", "6.24428997"], ["d", "M306.42601,250.02579 L306.42601,255.235353 C306.42601,258.248347 308.874337,260.699106 311.88835,260.699106 L520.175933,260.699106 C523.187441,260.699106 525.638273,258.249893 525.638273,255.235353 L525.638273,250.02579 C525.638273,249.884133 525.525092,249.771599 525.379413,249.771599 L306.68487,249.771599 C306.538643,249.771599 306.42601,249.8841 306.42601,250.02579 Z", "id", "Keyboard", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["d", "M430.428848,249.888735 L401.270407,249.88823 C402.433781,252.961493 405.402425,255.091813 408.808279,255.091813 L422.891133,255.091813 C426.2974,255.091813 429.265465,252.961765 430.428848,249.888735 Z", "id", "Notch", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["id", "Screen", "stroke", "#39FF14", "stroke-width", "2.08142999", "x", "328.295034", "y", "132.691162", "width", "175.319716", "height", "105.073079", "rx", "2.08142999"], ["id", "Oval-3", "fill", "#293347", "cx", "254.357573", "cy", "49.9543198", "rx", "1.3017276", "ry", "1.30089374"], ["d", "M179.899422,11.9682224 L300.177718,11.9682224 L300.177718,127.227794 C300.177718,131.24909 296.908511,134.512413 292.886465,134.512413 L187.190674,134.512413 C183.165634,134.512413 179.899422,131.247907 179.899422,127.227794 L179.899422,11.9682224 Z", "id", "Case", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["d", "M179.899422,6.23775036 C179.899422,2.21962044 183.168858,-1.040715 187.190674,-1.040715 L292.886465,-1.040715 C296.913475,-1.040715 300.177718,2.21613142 300.177718,6.23775036 L300.177718,14.0496524 L179.899422,14.0496524 L179.899422,6.23775036 Z", "id", "Case", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["id", "Oval-5", "fill", "#39FF14", "cx", "191.093612", "cy", "6.50446872", "rx", "2.34310968", "ry", "2.34160874"], ["id", "Oval-5", "fill", "#39FF14", "cx", "198.903978", "cy", "6.50446872", "rx", "2.34310968", "ry", "2.34160874"], ["id", "Oval-5", "fill", "#39FF14", "cx", "206.714343", "cy", "6.50446872", "rx", "2.34310968", "ry", "2.34160874"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "194.478104", "y", "87.9404171", "width", "4.68621937", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "194.478104", "y", "35.9046673", "width", "4.68621937", "height", "2.08142999", "rx", "1.040715"], ["d", "M203.329184,35.9046673 L210.359847,35.9046673 C210.934619,35.9046673 211.400562,36.3706113 211.400562,36.9453823 C211.400562,37.5201533 210.934619,37.9860973 210.359847,37.9860973 L203.329184,37.9860973 C202.754413,37.9860973 202.288469,37.5201533 202.288469,36.9453823 C202.288469,36.3706113 202.754413,35.9046673 203.329184,35.9046673 Z", "id", "Rectangle-11", "fill", "#39FF14"], ["d", "M215.044733,35.9046673 L222.075396,35.9046673 C222.650167,35.9046673 223.116111,36.3706113 223.116111,36.9453823 C223.116111,37.5201533 222.650167,37.9860973 222.075396,37.9860973 L215.044733,37.9860973 C214.469962,37.9860973 214.004018,37.5201533 214.004018,36.9453823 C214.004018,36.3706113 214.469962,35.9046673 215.044733,35.9046673 Z", "id", "Rectangle-11", "fill", "#39FF14"], ["d", "M226.760281,35.9046673 L239.778891,35.9046673 C240.353662,35.9046673 240.819606,36.3706113 240.819606,36.9453823 C240.819606,37.5201533 240.353662,37.9860973 239.778891,37.9860973 L226.760281,37.9860973 C226.18551,37.9860973 225.719566,37.5201533 225.719566,36.9453823 C225.719566,36.3706113 226.18551,35.9046673 226.760281,35.9046673 Z", "id", "Rectangle-11", "fill", "#39FF14"], ["d", "M244.463776,35.9046673 L263.730679,35.9046673 C264.30545,35.9046673 264.771394,36.3706113 264.771394,36.9453823 C264.771394,37.5201533 264.30545,37.9860973 263.730679,37.9860973 L244.463776,37.9860973 C243.889005,37.9860973 243.423061,37.5201533 243.423061,36.9453823 C243.423061,36.3706113 243.889005,35.9046673 244.463776,35.9046673 Z", "id", "Rectangle-11", "fill", "#39FF14"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "194.478104", "y", "46.3118173", "width", "4.68621937", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "194.478104", "y", "56.7189672", "width", "4.68621937", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "194.478104", "y", "67.1261172", "width", "4.68621937", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "194.478104", "y", "77.5332671", "width", "4.68621937", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "194.478104", "y", "98.347567", "width", "4.68621937", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "194.478104", "y", "108.754717", "width", "4.68621937", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "202.288469", "y", "46.3118173", "width", "18.2241864", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "223.116111", "y", "46.3118173", "width", "31.2414624", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "256.961029", "y", "46.3118173", "width", "13.017276", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "202.288469", "y", "56.7189672", "width", "13.017276", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "217.9092", "y", "56.7189672", "width", "13.017276", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "233.529932", "y", "56.7189672", "width", "7.81036561", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "202.288469", "y", "67.1261172", "width", "26.034552", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "230.926476", "y", "67.1261172", "width", "18.2241864", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "202.288469", "y", "77.5332671", "width", "26.034552", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "230.926476", "y", "77.5332671", "width", "33.8449176", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "202.288469", "y", "87.9404171", "width", "18.2241864", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "223.116111", "y", "87.9404171", "width", "18.2241864", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "243.943753", "y", "87.9404171", "width", "10.4138208", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "202.288469", "y", "98.347567", "width", "33.8449176", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "202.288469", "y", "108.754717", "width", "15.6207312", "height", "2.08142999", "rx", "1.040715"], ["d", "M414.991426,93.6643496 L557.659437,93.6643496 L557.659437,195.142937 C557.659437,199.162932 554.399545,202.419067 550.373649,202.419067 L422.277215,202.419067 C418.255898,202.419067 414.991426,199.157214 414.991426,195.142937 L414.991426,93.6643496 Z", "id", "Case", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["d", "M414.991426,87.9338775 C414.991426,83.9126798 418.251232,80.6554121 422.277215,80.6554121 L550.373649,80.6554121 C554.397843,80.6554121 557.659437,83.9124627 557.659437,87.9338775 L557.659437,95.7457795 L414.991426,95.7457795 L414.991426,87.9338775 Z", "id", "Case", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["id", "Oval-5", "fill", "#39FF14", "cx", "426.185617", "cy", "88.2005958", "rx", "2.34310968", "ry", "2.34160874"], ["id", "Oval-5", "fill", "#39FF14", "cx", "433.995982", "cy", "88.2005958", "rx", "2.34310968", "ry", "2.34160874"], ["id", "Oval-5", "fill", "#39FF14", "cx", "441.806348", "cy", "88.2005958", "rx", "2.34310968", "ry", "2.34160874"], ["id", "Oval-6", "stroke", "#39FF14", "stroke-width", "2.34160874", "cx", "503.247891", "cy", "148.041708", "rx", "26.034552", "ry", "26.0178749"], ["d", "M500.383423,118.901688 L500.383423,125.145978 L506.63305,125.145978 L506.63305,118.901688 L500.383423,118.901688 Z", "id", "Rectangle-12", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["d", "M500.123077,170.937438 L500.123077,177.181728 L506.372704,177.181728 L506.372704,170.937438 L500.123077,170.937438 Z", "id", "Rectangle-12", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["d", "M474.088525,145.179742 L474.088525,151.424032 L480.338152,151.424032 L480.338152,145.179742 L474.088525,145.179742 Z", "id", "Rectangle-12", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["d", "M525.897284,145.179742 L525.897284,151.424032 L532.146911,151.424032 L532.146911,145.179742 L525.897284,145.179742 Z", "id", "Rectangle-12", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["x1", "529.282443", "y1", "124.625621", "x2", "529.282443", "y2", "144.139027", "id", "Line", "stroke", "#39FF14", "stroke-width", "2.08142999", "stroke-linecap", "square"], ["x1", "529.282443", "y1", "151.944389", "x2", "529.282443", "y2", "171.457795", "id", "Line", "stroke", "#39FF14", "stroke-width", "2.08142999", "stroke-linecap", "square"], ["id", "Oval-5", "fill", "#39FF14", "cx", "529.282443", "cy", "123.845084", "rx", "3.12414624", "ry", "3.12214499"], ["id", "Oval-5", "fill", "#39FF14", "cx", "529.282443", "cy", "173.279047", "rx", "3.12414624", "ry", "3.12214499"], ["id", "Group-60", "transform", "translate(439.463238, 115.519364)", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["id", "Rectangle-15", "x", "1.040715", "y", "1.040715", "width", "16.1427564", "height", "16.1310824", "rx", "3.12214499"], ["id", "Rectangle-15", "x", "1.040715", "y", "24.4568024", "width", "16.1427564", "height", "16.1310824", "rx", "3.12214499"], ["id", "Rectangle-15", "x", "1.040715", "y", "47.8728898", "width", "16.1427564", "height", "16.1310824", "rx", "3.12214499"], ["id", "Oval-8", "stroke", "#39FF14", "stroke-width", "2.08142999", "cx", "632.379269", "cy", "235.982125", "rx", "15.6207312", "ry", "15.6107249"], ["id", "Oval-8", "stroke", "#39FF14", "stroke-width", "2.08142999", "cx", "632.379269", "cy", "235.982125", "rx", "9.11209321", "ry", "9.10625621"], ["id", "Oval-8", "stroke", "#39FF14", "stroke-width", "2.08142999", "cx", "611.551627", "cy", "212.305859", "rx", "5.20691041", "ry", "5.20357498"], ["d", "M588.639887,211.004965 C588.065116,211.004965 587.599172,211.470909 587.599172,212.04568 L587.599172,255.75571 C587.599172,258.629565 589.928892,260.959285 592.802747,260.959285 L628.720118,260.959285 C631.593973,260.959285 633.923693,258.629565 633.923693,255.75571 L633.923693,212.04568 C633.923693,211.470909 633.457749,211.004965 632.882978,211.004965 L588.639887,211.004965 Z", "id", "Rectangle-16", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["id", "Rectangle-16", "stroke", "#39FF14", "stroke-width", "2.08142999", "x", "609.728541", "y", "225.054618", "width", "13.5393012", "height", "16.6514399", "rx", "3.12214499"], ["x1", "616.368019", "y1", "211.395233", "x2", "616.368019", "y2", "223.233366", "id", "Line-2", "stroke", "#39FF14", "stroke-width", "2.08142999", "stroke-linecap", "square"], ["d", "M557.92045,260.699106 C566.547542,260.699106 573.541181,260.699106 573.541181,260.699106 C573.541181,252.077541 566.547542,245.088381 557.92045,245.088381 C549.293358,245.088381 542.299719,252.077541 542.299719,260.699106 C542.299719,260.699106 549.293358,260.699106 557.92045,260.699106 Z", "id", "Oval-8", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["id", "Rectangle-11", "fill", "#39FF14", "x", "556.879068", "y", "244.568024", "width", "2.08276416", "height", "3.38232373", "rx", "1.04138208"], ["d", "M16.391389,229.997886 C7.91344584,229.997886 1.040715,236.870617 1.040715,245.34856 C1.040715,253.826503 7.91344584,260.699234 16.391389,260.699234 L79.4070531,260.699234 C80.2692097,260.699234 80.9681256,260.000318 80.9681256,259.138161 L80.9681256,256.722169 C80.9681256,255.629844 80.123732,254.723351 79.0341503,254.645969 C71.8803755,254.137863 68.0805122,250.995245 68.0805122,245.34856 C68.0805122,239.701873 71.8803788,236.559254 79.0341596,236.05115 C80.1237345,235.973762 80.9681256,235.06727 80.9681256,233.974951 L80.9681256,231.558958 C80.9681256,230.696802 80.2692097,229.997886 79.4070531,229.997886 L16.391389,229.997886 Z", "id", "Rectangle-17", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["d", "M80.1864202,255.299762 C80.1864202,255.551575 79.9821545,255.75571 79.73018,255.75571 L79.73018,255.75571 L72.353427,255.75571 L16.1414223,255.75571 C10.3900278,255.75571 5.72760145,251.09627 5.72760145,245.34856 C5.72760145,239.60085 10.3900278,234.94141 16.1414223,234.94141 L72.353427,234.94141 L79.73018,234.94141 L79.73018,234.94141 C79.9821545,234.94141 80.1864202,235.145545 80.1864202,235.397358", "id", "Rectangle-19", "stroke", "#39FF14", "stroke-width", "2.08142999"], ["id", "Rectangle-18", "fill", "#39FF14", "x", "14.0586581", "y", "240.925521", "width", "54.6725593", "height", "2.08142999", "rx", "1.040715"], ["id", "Rectangle-18", "fill", "#39FF14", "x", "14.0586581", "y", "247.42999", "width", "54.6725593", "height", "2.08142999", "rx", "1.040715"], ["d", "M65.1265421,178.055093 C63.848875,176.91993 62.5712079,175.784766 61.2935408,174.649603 C59.2574411,172.842608 57.2271756,171.029822 55.1910759,169.222827 C54.7243482,168.81162 54.2576205,168.394621 53.7967269,167.983414 C53.7967269,168.527829 53.7967269,169.078035 53.7967269,169.622451 C55.074394,168.487287 56.3520611,167.352124 57.6297282,166.21696 C59.6658279,164.409965 61.6960934,162.597179 63.7321931,160.790184 C64.1989208,160.378977 64.6656485,159.961978 65.1265421,159.550771 C65.5816017,159.145355 65.5757676,158.317149 65.1265421,157.911734 C64.6423121,157.465777 63.965557,157.47736 63.4754929,157.911734 C62.1978257,159.046897 60.9201586,160.182061 59.6424915,161.317224 C57.6063919,163.124219 55.5761263,164.937006 53.5400267,166.744 C53.0732989,167.155208 52.6065712,167.572206 52.1456776,167.983414 C51.6964522,168.383037 51.6964522,169.222827 52.1456776,169.622451 C53.4233447,170.757614 54.7010118,171.892778 55.978679,173.027941 C58.0147786,174.834936 60.0450442,176.647722 62.0811438,178.454717 C62.5478715,178.865924 63.0145992,179.282923 63.4754929,179.69413 C63.9305524,180.099546 64.6831508,180.174837 65.1265421,179.69413 C65.5349289,179.253965 65.6107721,178.489467 65.1265421,178.055093 L65.1265421,178.055093 Z", "id", "Shape", "fill", "#39FF14", "fill-rule", "nonzero"], ["d", "M84.5825817,159.553526 C85.8602488,160.688689 87.1379159,161.823853 88.415583,162.959016 C90.4516827,164.766011 92.4819482,166.578798 94.5180479,168.385793 C94.9847756,168.797 95.4515033,169.213999 95.9123969,169.625206 C95.9123969,169.080791 95.9123969,168.530584 95.9123969,167.986169 C94.6347298,169.121332 93.3570627,170.256496 92.0793956,171.391659 C90.0432959,173.198654 88.0130304,175.011441 85.9769307,176.818435 C85.510203,177.229643 85.0434753,177.646641 84.5825817,178.057849 C84.1275221,178.463264 84.1333562,179.29147 84.5825817,179.696886 C85.0668117,180.142843 85.7435668,180.131259 86.2336309,179.696886 C87.5112981,178.561722 88.7889652,177.426559 90.0666323,176.291395 C92.1027319,174.4844 94.1329975,172.671614 96.1690971,170.864619 C96.6358249,170.453412 97.1025526,170.036413 97.5634462,169.625206 C98.0126716,169.225582 98.0126716,168.385793 97.5634462,167.986169 C96.2857791,166.851005 95.008112,165.715842 93.7304448,164.580678 C91.6943452,162.773684 89.6640796,160.960897 87.62798,159.153902 C87.1612523,158.742695 86.6945246,158.325696 86.2336309,157.914489 C85.7785714,157.509074 85.025973,157.433782 84.5825817,157.914489 C84.1741949,158.354654 84.0983517,159.119152 84.5825817,159.553526 L84.5825817,159.553526 Z", "id", "Shape", "fill", "#39FF14", "fill-rule", "nonzero"], ["d", "M70.6937286,184.875712 C71.0437744,183.833215 71.3879861,182.790718 71.7380319,181.74243 C72.5723077,179.234645 73.4065835,176.732652 74.2408593,174.224868 C75.2443239,171.201626 76.2477884,168.184177 77.2570871,165.160935 C78.1263675,162.548901 78.9956479,159.936867 79.8649282,157.324832 C80.2791491,156.056461 80.7458768,154.793881 81.1309271,153.508135 C81.1367612,153.49076 81.1425953,153.473385 81.1484294,153.45601 C81.3409546,152.882637 80.9267338,152.164472 80.3316559,152.031264 C79.6899053,151.886473 79.1006616,152.222388 78.8964682,152.842095 C78.5464224,153.884592 78.2022107,154.927089 77.852165,155.975378 C77.0178892,158.483162 76.1836134,160.985155 75.3493376,163.49294 C74.345873,166.516181 73.3424084,169.533631 72.3331097,172.556872 C71.4638294,175.168907 70.594549,177.780941 69.7252686,180.392975 C69.3110478,181.655555 68.8443201,182.918135 68.4592697,184.203881 C68.4534356,184.221256 68.4476015,184.238631 68.4417674,184.256006 C68.2492422,184.829379 68.6634631,185.547544 69.2585409,185.680752 C69.9002915,185.825543 70.4895353,185.489627 70.6937286,184.875712 L70.6937286,184.875712 Z", "id", "Shape", "fill", "#39FF14", "fill-rule", "nonzero"]], template: function ToolsSvgComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "svg", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "g", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "g", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "path", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "path", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "path", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "path", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "ellipse", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "rect", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "path", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "rect", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "rect", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "ellipse", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](13, "rect", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](14, "rect", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "rect", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](16, "ellipse", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "rect", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](19, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](20, "rect", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](21, "ellipse", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](22, "path", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "path", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](24, "ellipse", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](25, "ellipse", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](26, "ellipse", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](27, "rect", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](28, "rect", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](29, "path", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](30, "path", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](31, "path", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](32, "path", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](33, "rect", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](34, "rect", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](35, "rect", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](36, "rect", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](37, "rect", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](38, "rect", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](39, "rect", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](40, "rect", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](41, "rect", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](42, "rect", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](43, "rect", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](44, "rect", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](45, "rect", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](46, "rect", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](47, "rect", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](48, "rect", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](49, "rect", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](50, "rect", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](51, "rect", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](52, "rect", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](53, "rect", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](54, "path", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](55, "path", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](56, "ellipse", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](57, "ellipse", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](58, "ellipse", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](59, "ellipse", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](60, "path", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](61, "path", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](62, "path", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](63, "path", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](64, "line", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](65, "line", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](66, "ellipse", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](67, "ellipse", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "g", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](69, "rect", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](70, "rect", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](71, "rect", 71);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](72, "ellipse", 72);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](73, "ellipse", 73);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](74, "ellipse", 74);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](75, "path", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](76, "rect", 76);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](77, "line", 77);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](78, "path", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](79, "rect", 79);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](80, "path", 80);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](81, "path", 81);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](82, "rect", 82);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](83, "rect", 83);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](84, "path", 84);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](85, "path", 85);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](86, "path", 86);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("fill", ctx.bg);
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0b29scy1zdmcuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ "y4qi":
/*!*************************************************************!*\
  !*** ./src/app/core/splash-screen/splash-screen.service.ts ***!
  \*************************************************************/
/*! exports provided: SplashScreenService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SplashScreenService", function() { return SplashScreenService; });
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/animations */ "R0Ic");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");



class SplashScreenService {
    constructor(animationBuilder) {
        this.animationBuilder = animationBuilder;
    }
    /**
     * Init
     * @param element: ElementRef
     */
    init(element) {
        this.el = element;
    }
    // Hide splash screen
    hide() {
        if (this.stopped || !this.el)
            return;
        const player = this.animationBuilder
            .build([Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ opacity: '1' }), Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["animate"])(1500, Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ opacity: '0' }))])
            .create(this.el.nativeElement);
        player.onDone(() => {
            if (!this.el)
                return;
            if (typeof this.el.nativeElement.remove === 'function')
                this.el.nativeElement.remove();
            else
                this.el.nativeElement.style.display = 'none !important';
            this.stopped = true;
        });
        setTimeout(() => player.play(), 100);
    }
}
SplashScreenService.ɵfac = function SplashScreenService_Factory(t) { return new (t || SplashScreenService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_animations__WEBPACK_IMPORTED_MODULE_0__["AnimationBuilder"])); };
SplashScreenService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: SplashScreenService, factory: SplashScreenService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "yuSF":
/*!***************************************************************!*\
  !*** ./src/app/core/splash-screen/splash-screen.component.ts ***!
  \***************************************************************/
/*! exports provided: SplashScreenComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SplashScreenComponent", function() { return SplashScreenComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _splash_screen_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./splash-screen.service */ "y4qi");


const _c0 = ["splashScreen"];
class SplashScreenComponent {
    constructor(splashScreenService) {
        this.splashScreenService = splashScreenService;
    }
    ngOnInit() { }
    ngAfterViewInit() {
        //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
        //Add 'implements AfterViewInit' to the class.
        if (this.splashScreen)
            this.splashScreenService.init(this.splashScreen);
    }
}
SplashScreenComponent.ɵfac = function SplashScreenComponent_Factory(t) { return new (t || SplashScreenComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_splash_screen_service__WEBPACK_IMPORTED_MODULE_1__["SplashScreenService"])); };
SplashScreenComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: SplashScreenComponent, selectors: [["app-splash-screen"]], viewQuery: function SplashScreenComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 1);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.splashScreen = _t.first);
    } }, decls: 4, vars: 0, consts: [[1, "page-loader", "page-loader-logo"], ["splashScreen", ""], ["src", "./assets/media/logos/logo-letter-4.png", "alt", "Logo", 1, "max-h-75px"], [1, "spinner", "spinner-primary"]], template: function SplashScreenComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "img", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcGxhc2gtc2NyZWVuLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ "zUnb":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "ZAI4");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "AytR");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ "zn8P":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "zn8P";

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map