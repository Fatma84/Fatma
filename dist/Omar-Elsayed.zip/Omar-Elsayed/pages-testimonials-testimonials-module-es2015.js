(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-testimonials-testimonials-module"],{

/***/ "jiYq":
/*!***********************************************************!*\
  !*** ./src/app/pages/testimonials/testimonials.module.ts ***!
  \***********************************************************/
/*! exports provided: TestimonialsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestimonialsPageModule", function() { return TestimonialsPageModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _testimonials_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./testimonials.page */ "m5OE");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");





const routes = [{ path: '', component: _testimonials_page__WEBPACK_IMPORTED_MODULE_2__["TestimonialsPage"] }];
class TestimonialsPageModule {
}
TestimonialsPageModule.ɵfac = function TestimonialsPageModule_Factory(t) { return new (t || TestimonialsPageModule)(); };
TestimonialsPageModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: TestimonialsPageModule });
TestimonialsPageModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](TestimonialsPageModule, { declarations: [_testimonials_page__WEBPACK_IMPORTED_MODULE_2__["TestimonialsPage"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] }); })();


/***/ }),

/***/ "m5OE":
/*!*********************************************************!*\
  !*** ./src/app/pages/testimonials/testimonials.page.ts ***!
  \*********************************************************/
/*! exports provided: TestimonialsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestimonialsPage", function() { return TestimonialsPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");

class TestimonialsPage {
    constructor() { }
    ngOnInit() { }
}
TestimonialsPage.ɵfac = function TestimonialsPage_Factory(t) { return new (t || TestimonialsPage)(); };
TestimonialsPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: TestimonialsPage, selectors: [["page-testimonials"]], decls: 2, vars: 0, template: function TestimonialsPage_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "testimonials works!");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0ZXN0aW1vbmlhbHMucGFnZS5zY3NzIn0= */"] });


/***/ })

}]);
//# sourceMappingURL=pages-testimonials-testimonials-module-es2015.js.map